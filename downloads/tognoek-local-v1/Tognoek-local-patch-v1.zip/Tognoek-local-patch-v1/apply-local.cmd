@echo off
setlocal
title Tognoek local patch
powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0apply-local.ps1"
if errorlevel 1 pause
