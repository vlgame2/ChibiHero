﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms

function Get-BytesHash([byte[]] $value) {
    $hasher = [System.Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($hasher.ComputeHash($value))).Replace('-', '').ToLowerInvariant() }
    finally { $hasher.Dispose() }
}

try {
    $specPath = Join-Path $PSScriptRoot 'patch.json'
    $spec = [System.IO.File]::ReadAllText($specPath, [System.Text.Encoding]::UTF8) | ConvertFrom-Json
    $picker = New-Object System.Windows.Forms.OpenFileDialog
    $picker.Title = 'Chọn tognoek-sv.exe trong bộ release gốc'
    $picker.Filter = 'Tognoek gốc (tognoek-sv.exe)|tognoek-sv.exe'
    if ($picker.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { exit 0 }
    $sourceFile = $picker.FileName
    $picker.Dispose()
    $originalBytes = [System.IO.File]::ReadAllBytes($sourceFile)
    if ($originalBytes.Length -ne [int]$spec.source_bytes -or (Get-BytesHash $originalBytes) -ne $spec.source_sha256) {
        throw 'EXE không đúng bản release đã kiểm tra. Hãy chọn tệp gốc từ gói release bạn đã gửi.'
    }

    $resultBytes = New-Object byte[] ([int]$spec.output_bytes)
    [Array]::Copy($originalBytes, 0, $resultBytes, 0, $originalBytes.Length)
    foreach ($edit in $spec.edits) {
        $offset = [int]$edit.offset
        $before = [Convert]::FromBase64String([string]$edit.before)
        $after = [Convert]::FromBase64String([string]$edit.after)
        if ($before.Length -ne $after.Length -or $offset -lt 0 -or $offset + $before.Length -gt $originalBytes.Length) {
            throw 'Gói vá không hợp lệ.'
        }
        for ($index = 0; $index -lt $before.Length; $index++) {
            if ($originalBytes[$offset + $index] -ne $before[$index]) { throw 'Dữ liệu đầu vào không khớp gói vá.' }
        }
        [Array]::Copy($after, 0, $resultBytes, $offset, $after.Length)
    }
    $tail = [Convert]::FromBase64String([string]$spec.append)
    if ($originalBytes.Length + $tail.Length -ne $resultBytes.Length) { throw 'Kích thước gói vá không hợp lệ.' }
    [Array]::Copy($tail, 0, $resultBytes, $originalBytes.Length, $tail.Length)
    if ((Get-BytesHash $resultBytes) -ne $spec.output_sha256) { throw 'Kết quả vá không khớp SHA-256 dự kiến.' }

    $sourceFolder = [System.IO.Path]::GetDirectoryName($sourceFile)
    $parentFolder = [System.IO.Path]::GetDirectoryName($sourceFolder)
    if ([string]::IsNullOrEmpty($parentFolder)) { throw 'Hãy đặt bộ release trong một thư mục riêng rồi thử lại.' }
    $folderName = [System.IO.Path]::GetFileName($sourceFolder) + '-local-' + (Get-Date -Format 'yyyyMMdd-HHmmss')
    $targetFolder = Join-Path $parentFolder $folderName
    if (Test-Path -LiteralPath $targetFolder) { $targetFolder += '-' + [Guid]::NewGuid().ToString('N').Substring(0, 8) }
    Write-Host 'Đang tạo bản sao của thư mục release...'
    Copy-Item -LiteralPath $sourceFolder -Destination $targetFolder -Recurse
    $outputFile = Join-Path $targetFolder 'tognoek-sv.exe'
    [System.IO.File]::WriteAllBytes($outputFile, $resultBytes)
    if ((Get-BytesHash ([System.IO.File]::ReadAllBytes($outputFile))) -ne $spec.output_sha256) {
        throw 'Tệp đã ghi chưa khớp SHA-256 dự kiến.'
    }
    if ((Get-BytesHash ([System.IO.File]::ReadAllBytes($sourceFile))) -ne $spec.source_sha256) {
        throw 'EXE gốc đã thay đổi trong lúc sao chép; hãy giữ lại cả hai thư mục để kiểm tra.'
    }
    [System.Windows.Forms.MessageBox]::Show(
        "Đã tạo bản thử tại:`r`n$targetFolder`r`n`r`nĐóng bản cũ, rồi mở tognoek-sv.exe trong thư mục mới. Chạy thử một tài khoản trước; bản này chưa được kiểm chứng game trên Windows.",
        'Tognoek — chế độ cục bộ') | Out-Null
    Start-Process -FilePath 'explorer.exe' -ArgumentList ('"' + $targetFolder + '"')
}
catch {
    [System.Windows.Forms.MessageBox]::Show($_.Exception.Message, 'Chưa tạo được bản thử') | Out-Null
    exit 1
}
