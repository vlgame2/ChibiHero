package mod;

import IIlIiIliiiillIi1lilii1lill1I.i1liIIii1IlIl1illlIIilIl;
import IIlIiIliiiillIi1lilii1lill1I.i1i11I1iil1lIl;
import IIlIiIliiiillIi1lilii1lill1I.l1l11llilI1lllIi11;
import IIlIiIliiiillIi1lilii1lill1I.IIIIliIilIIili1I1l11;
import IIlIiIliiiillIi1lilii1lill1I.IIIiilililIilIli;
import java.io.FileWriter;

/** Trading only. Does not read or change the Farm revival mode. */
public final class TradeSessionGuard {
    private static Object deadCharacter, deadScene, followed;
    private static long deathAt, sentAt;
    private static boolean sent, waiting, wasStunned, deadV3;
    private static short[] approachPath;
    private static int approachX,approachY;
    private static Object changingCharacter,changingScene,changingAnimal;
    private static int changingType,changingId;
    private static boolean changingV3;
    private static long changingSince;
    private static int attempts;
    private static final int TILE=24, RESUME=24;
    private TradeSessionGuard() {}

    public static long delayMillis(int seconds) {
        return seconds<=1 ? 0L : Math.min(seconds,15)*1000L;
    }
    private static boolean valid(boolean enabled, boolean v3) {
        if(!enabled || (!v3 && ModAutoTradeV3.IIlIiIliiiillIi1lilii1lill1I)) return false;
        if(i1liIIii1IlIl1illlIIilIl.i1iiIi11IIilI1IiiIl11==null ||
            IIIiilililIilIli.IIIiiiiliIl1Iiiii11==null) return false;
        if(!mod.i1liIIii1IlIl1illlIIilIl.IIlIiIliiiillIi1lilii1lill1I("auto_dibuon")) return false;
        if(mod.IIIiilililIilIli.IliIl1i11Ilii1li1II1iIl("ModAutoDungeon")) return false;
        return !v3 || (!ModAutoKhuMuaBan.IIlIiIliiiillIi1lilii1lill1I() &&
            !mod.illIi1ilI1IIi1iii.IIlIiIliiiillIi1lilii1lill1I() &&
            !mod.liiI1lilIlilli11ii1Il.IIlIiIliiiillIi1lilii1lill1I());
    }
    private static boolean dead(l1l11llilI1lllIi11 p) {
        return p.IlIIl1I1IIIililIil1iiI==4 || p.ilIII1111l1i1liIil11<=0;
    }
    private static void stop(boolean v3) {
        if(v3) ModAutoTradeV3.hsoLeashStop(); else ModAutoTrade.hsoLeashStop();
        i1i11I1iil1lIl p=i1liIIii1IlIl1illlIIilIl.i1iiIi11IIilI1IiiIl11;
        if(p==null) return;
        p.li1i1ll1liIIlIlI1IlII=null;
        p.l1i1ili1Iill11Ii1iIII11liI1=0; p.iIIlI1lI1lIlI1il1liiiI1l=0;
        p.Ii1iliII1l1I1III1l=p.l1IilIi1ilil1lli1I1lii1Ill;
        p.iIlIi1iIi11IlI=p.l11iliIII1ii1lilI1IlIl;
        p.i1IiI111lIllI1lIIlI=0; p.iliI1liil1llii111Ililil=0;
        p.l1l1iIiIiIlIi1l11=0;
    }
    private static void resetDeath() {
        deadCharacter=null;deadScene=null;deathAt=0;sentAt=0;sent=false;attempts=0;
    }
    public static boolean revive(boolean enabled, boolean v3) {
        try {
            if(!valid(enabled,v3)) {
                if(deadCharacter!=null && deadV3==v3) resetDeath();
                if(changingCharacter!=null && changingV3==v3) clearChanging();
                return false;
            }
            i1i11I1iil1lIl p=i1liIIii1IlIl1illlIIilIl.i1iiIi11IIilI1IiiIl11;
            if(!dead(p)) {
                try { maintainDeadAnimal(v3,false); } catch(Throwable ignored) { clearChanging(); }
                if(deadCharacter==p && sent) log("alive after_ms="+((System.nanoTime()-deathAt)/1000000L)+" requests="+attempts);
                resetDeath();return false;
            }
            long now=System.nanoTime();
            Object scene=IIIiilililIilIli.IIIiiiiliIl1Iiiii11;
            if(deadCharacter!=p || deadScene!=scene) {
                resetDeath();deadCharacter=p;deadScene=scene;deathAt=now;deadV3=v3;
            }
            waiting=false;followed=null;approachPath=null;stop(v3);
            long delay=delayMillis(ModAutoTrade.llliilIillilIiiIi)*1000000L;
            // No initial wait at setting 1. Bound retries to four per second.
            if((!sent && now-deathAt>=delay) || (sent && now-sentAt>=Math.max(delay,250000000L))) {
                // Existing in-place action used by BOTH the target and reference.
                // Resource consumption (revival item / gems) is decided by the game.
                IIIIliIilIIili1I1l11.l1lli1lIliIiiiIliIilII().l1lli1lIliIiiiIliIilII((short)-51,(byte)0,(byte)0);
                sentAt=System.nanoTime();sent=true;attempts++;
                // Dispatch first; disk logging and animal menus cannot delay it.
                if(attempts==1) log("in_place_request elapsed_ms="+((sentAt-deathAt)/1000000L)+
                    " delay_setting="+ModAutoTrade.llliilIillilIiiIi+" mode="+(v3?"V3":"classic"));
            }
            try { maintainDeadAnimal(v3,true); } catch(Throwable ignored) { clearChanging(); }
            return true;
        } catch(Throwable failure) {
            // Keep ownership of a dead trading character; never fall through to
            // a competing revival mode or a flood of unthrottled old requests.
            if(deadCharacter!=null) {sent=true;sentAt=System.nanoTime();return true;}
            return false;
        }
    }
    public static boolean stunned(l1l11llilI1lllIi11 animal) {
        // Real movement-blocking flags, set/cleared by game effect handlers.
        return animal.iIIIli1Ilil1Ili11lli1 || animal.liiIIil1i1iIII1i ||
            animal.lIi1i1li1I1llii11Iii1i1ll || animal.Ilii1iIIIIlIil1ii ||
            animal.Il1IIii1lllIlIlIl1II1ii1iIl;
    }
    private static int distance(int x,int y,l1l11llilI1lllIi11 a) {
        return Math.abs(x-a.l1IilIi1ilil1lli1I1lii1Ill)+Math.abs(y-a.l11iliIII1ii1lilI1IlIl);
    }
    public static boolean beforeLead(boolean v3) {
        i1i11I1iil1lIl p=i1liIIii1IlIl1illlIIilIl.i1iiIi11IIilI1IiiIl11;
        l1l11llilI1lllIi11 a=ModAutoTrade.llIIilIiiiIl1lII11();
        if(p==null || a==null || dead(p) || a.ilIII1111l1i1liIil11<=0 || a.iIlii1I1Ili1iIIllIiI1IiIliI) {
            waiting=false;wasStunned=false;followed=null;return false;
        }
        if(followed!=a) {waiting=false;wasStunned=false;followed=a;}
        int d=distance(p.l1IilIi1ilil1lli1I1lii1Ill,p.l11iliIII1ii1lilI1IlIl,a);
        boolean stun=stunned(a);
        boolean recovering=waiting;
        waiting=stun;
        if(!waiting) {
            if(recovering) stop(v3); // discard approach path, rebuild trade route
            wasStunned=false;approachPath=null;return false;
        }
        if(stun && !wasStunned) log("animal_stun wait_beside");
        wasStunned=stun;
        // Do not restart the same path every tick: that would repeatedly walk
        // back to its first node instead of reaching the animal.
        if(d>RESUME && approachPath!=null && p.li1i1ll1liIIlIlI1IlII==approachPath &&
            approachX==a.l1IilIi1ilil1lli1I1lii1Ill && approachY==a.l11iliIII1ii1lilI1IlIl) return true;
        stop(v3);
        approachPath=null;
        if(d>RESUME) {
            // Normal obstacle-aware walking, never a teleport/coordinate edit.
            short[] path=i1liIIii1IlIl1illlIIilIl.lIlIIIIIiiiiII1l1l1iII1l1().IIlIiIliiiillIi1lilii1lill1I(
                a.l1IilIi1ilil1lli1I1lii1Ill/TILE,a.l11iliIII1ii1lilI1IlIl/TILE,
                p.l1IilIi1ilil1lli1I1lii1Ill/TILE,p.l11iliIII1ii1lilI1IlIl/TILE,500);
            if(path!=null && path.length>0 && path.length<500) {
                p.li1i1ll1liIIlIlI1IlII=path;
                approachPath=path;approachX=a.l1IilIi1ilil1lli1I1lii1Ill;approachY=a.l11iliIII1ii1lilI1IlIl;
                p.i1IiI111lIllI1lIIlI=a.l1IilIi1ilil1lli1I1lii1Ill;
                p.iliI1liil1llii111Ililil=a.l11iliIII1ii1lilI1IlIl;
            }
        }
        return true;
    }
    /** Only pause/approach for actual debuffs; normal trade routing is unchanged. */
    public static void fence(boolean enabled,boolean v3,int phase) {
        try {
            if(!valid(enabled,v3) || (phase!=2 && phase!=3)) return;
            i1i11I1iil1lIl p=i1liIIii1IlIl1illlIIilIl.i1iiIi11IIilI1IiiIl11;
            l1l11llilI1lllIi11 a=ModAutoTrade.llIIilIiiiIl1lII11();
            if(dead(p)||a==null) return;
            if(stunned(a)||waiting) beforeLead(v3);
        } catch(Throwable ignored) { /* Keep the original normal movement. */ }
    }
    /** Hold the normal low-HP handler until a living player is beside a stunned animal. */
    public static boolean approachBeforeReplace(boolean v3) {
        try {
            i1i11I1iil1lIl p=i1liIIii1IlIl1illlIIilIl.i1iiIi11IIilI1IiiIl11;
            l1l11llilI1lllIi11 a=ModAutoTrade.llIIilIiiiIl1lII11();
            if(p==null||dead(p)||a==null||!stunned(a)) return false;
            if(distance(p.l1IilIi1ilil1lli1I1lii1Ill,p.l11iliIII1ii1lilI1IlIl,a)<=RESUME) return false;
            return beforeLead(v3);
        } catch(Throwable ignored) {return false;}
    }
    private static void clearChanging() {
        changingCharacter=null;changingScene=null;changingAnimal=null;changingSince=0;
    }
    private static void maintainDeadAnimal(boolean v3,boolean isDead) {
        Object character=i1liIIii1IlIl1illlIIilIl.i1iiIi11IIilI1IiiIl11;
        Object scene=IIIiilililIilIli.IIIiiiiliIl1Iiiii11;
        int type=ModAutoTrade.lIlIIIIIiiiiII1l1l1iII1l1;
        int map=IIIiilililIilIli.IIIiiiiliIl1Iiiii11.IliIl1i11Ilii1li1II1iIl;
        long now=System.nanoTime();
        if(changingCharacter!=null && (character!=changingCharacter || scene!=changingScene ||
            type!=changingType || v3!=changingV3 || now-changingSince>=10000000000L)) clearChanging();
        if(map==33 || map==34 || type<0 || type>2) {clearChanging();return;}
        l1l11llilI1lllIi11 animal=ModAutoTrade.llIIilIiiiIl1lII11();
        if(changingCharacter!=null && animal!=null && changingId>0 && animal.IiIll1ii1lIll1i==changingId) changingAnimal=animal;
        if(changingCharacter!=null && animal!=null && animal!=changingAnimal) {
            TradeFastBridge.summonReady();clearChanging();
        }
        if(changingCharacter!=null && animal==null) {
            if(!TradeFastBridge.summon()) clearChanging();
            return;
        }
        if(!isDead && changingCharacter==null) return;
        if(animal==null || animal.Ii1lllIIl1llIiiI1i11IllI1<=0 ||
            animal.ilIII1111l1i1liIil11<=0 || animal.iIlii1I1Ili1iIIllIiI1IiIliI) return;
        int index=Math.max(0,Math.min(ModAutoTrade.l1iIiilIIII1I1llilI11Ili,3));
        int threshold=animal.Ii1lllIIl1llIiiI1i11IllI1*new int[]{30,50,70,90}[index]/100;
        if(animal.ilIII1111l1i1liIil11>=threshold) {clearChanging();return;}
        if(!isDead && approachBeforeReplace(v3)) return;
        if(TradeFastBridge.replace()) {
            if(changingCharacter==null) {
                changingCharacter=character;changingScene=scene;changingAnimal=animal;
                changingId=animal.IiIll1ii1lIll1i;
                changingType=type;changingV3=v3;changingSince=now;
                log("dead_animal_replace requested");
            }
        } else clearChanging();
    }
    private static void log(String event) {
        String line="[TRADE_V5] "+event;
        System.out.println(line);
        if("false".equals(System.getProperty("hso.trade.diagnostic"))) return;
        try {FileWriter out=new FileWriter("trade-v5-diagnostic.log",true);try {out.write(System.currentTimeMillis()+" "+line+"\n");}finally {out.close();}}catch(Exception ignored) {}
    }
}
