import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.JarOutputStream;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;

/** Add approach-before-replacement to the two existing low-HP handlers only. */
public final class PatchStunApproach implements Opcodes {
    private static final String CLASSIC="mod/ModAutoTrade";
    private static final String V3="mod/ModAutoTradeV3";
    private static final String HELPER="mod/TradeSessionGuard";
    private static ClassLoader hierarchy;
    private static int changed;

    private static byte[] patch(byte[] bytes, final String expected) {
        ClassNode c=new ClassNode();
        new ClassReader(bytes).accept(c,ClassReader.SKIP_FRAMES);
        if(!expected.equals(c.name)) throw new IllegalStateException("Unexpected class: "+c.name);
        boolean modern=V3.equals(c.name);
        String target=modern?"lII1i11iIlIililIli":"i1l1llIIIl11llII1i";
        int count=0;
        for(MethodNode m:c.methods) {
            if(!m.name.equals(target)||!m.desc.equals("()V")) continue;
            if((m.access&ACC_STATIC)==0) throw new IllegalStateException("Non-static low-HP handler");
            InsnList prefix=new InsnList();
            LabelNode normal=new LabelNode();
            prefix.add(new InsnNode(modern?ICONST_1:ICONST_0));
            prefix.add(new MethodInsnNode(INVOKESTATIC,HELPER,"approachBeforeReplace","(Z)Z",false));
            prefix.add(new JumpInsnNode(IFEQ,normal));
            prefix.add(new InsnNode(RETURN));
            prefix.add(normal);
            m.instructions.insert(prefix);
            count++;
        }
        if(count!=1) throw new IllegalStateException("Expected one low-HP handler in "+c.name+", got "+count);
        changed++;
        ClassWriter writer=new ClassWriter(ClassWriter.COMPUTE_FRAMES|ClassWriter.COMPUTE_MAXS) {
            @Override
            protected String getCommonSuperClass(String a,String b) {
                try {
                    Class<?> x=Class.forName(a.replace('/','.'),false,hierarchy);
                    Class<?> y=Class.forName(b.replace('/','.'),false,hierarchy);
                    if(x.isAssignableFrom(y)) return a;
                    if(y.isAssignableFrom(x)) return b;
                    if(x.isInterface()||y.isInterface()) return "java/lang/Object";
                    do {x=x.getSuperclass();} while(!x.isAssignableFrom(y));
                    return x.getName().replace('.','/');
                } catch(Exception failure) {
                    throw new IllegalStateException("Cannot resolve hierarchy: "+a+" / "+b,failure);
                }
            }
        };
        c.accept(writer);
        return writer.toByteArray();
    }

    private static byte[] read(InputStream in)throws Exception {
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        byte[] buffer=new byte[16384];int n;
        while((n=in.read(buffer))!=-1) out.write(buffer,0,n);
        return out.toByteArray();
    }

    public static void main(String[] args)throws Exception {
        if(args.length!=4) throw new IllegalArgumentException("input.jar core.jar original-jars-dir output.jar");
        Path input=Paths.get(args[0]),core=Paths.get(args[1]),original=Paths.get(args[2]),output=Paths.get(args[3]);
        if(input.toAbsolutePath().normalize().equals(output.toAbsolutePath().normalize()))
            throw new IllegalArgumentException("Output must differ from input");
        List<URL> urls=new ArrayList<URL>();
        urls.add(input.toUri().toURL());urls.add(core.toUri().toURL());
        try(DirectoryStream<Path> jars=Files.newDirectoryStream(original,"*.jar")) {
            for(Path p:jars) urls.add(p.toUri().toURL());
        }
        changed=0;
        try(URLClassLoader types=new URLClassLoader(urls.toArray(new URL[0]),PatchStunApproach.class.getClassLoader());
            JarFile jar=new JarFile(input.toFile())) {
            hierarchy=types;
            try(JarOutputStream dst=new JarOutputStream(Files.newOutputStream(output))) {
                Enumeration<JarEntry> entries=jar.entries();
                while(entries.hasMoreElements()) {
                    JarEntry entry=entries.nextElement();byte[] bytes;
                    try(InputStream in=jar.getInputStream(entry)) {bytes=read(in);}
                    if(entry.getName().equals(CLASSIC+".class")) bytes=patch(bytes,CLASSIC);
                    else if(entry.getName().equals(V3+".class")) bytes=patch(bytes,V3);
                    JarEntry copy=new JarEntry(entry.getName());copy.setTime(entry.getTime());
                    dst.putNextEntry(copy);dst.write(bytes);dst.closeEntry();
                }
            }
        }
        if(changed!=2) throw new IllegalStateException("Expected exactly two patched classes; got "+changed);
        System.out.println("Patched only the two low-HP handlers: approach a stunned distant animal before replacement; no helper appended.");
    }
}
