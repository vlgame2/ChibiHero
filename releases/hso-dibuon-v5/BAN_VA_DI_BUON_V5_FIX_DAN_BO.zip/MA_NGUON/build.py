from pathlib import Path
import subprocess,zipfile
R=Path('/workspace/tool-review');W=R/'trade-v5';V4=R/'trade-v4'
cp=':'.join([str(V4/'mod-auto-dibuon.jar'),str(R/'server-fix/core-bachho8.jar')]+[str(p) for p in (R/'target-resources').glob('*.jar')])
asmcp=':'.join(str(p) for p in (R/'tools').glob('asm*.jar'))
subprocess.run(['java','-jar',str(R/'tools/ecj.jar'),'-source','8','-target','8','-cp',asmcp,'-d',str(W/'classes'),str(W/'src/PatchTradeV4.java'),str(W/'src/PatchStunApproach.java'),str(W/'src/TestPackagedRuntime.java')],check=True)
subprocess.run(['java','-cp',str(W/'classes')+':'+asmcp,'PatchStunApproach',str(V4/'mod-auto-dibuon.jar'),str(R/'server-fix/core-bachho8.jar'),str(R/'target-resources'),str(W/'stun-approach.jar')],check=True)
subprocess.run(['java','-jar',str(R/'tools/ecj.jar'),'-source','8','-target','8','-encoding','UTF-8','-cp',cp,'-d',str(W/'classes'),str(W/'src/TradeSessionGuard.java')],check=True)
with zipfile.ZipFile(W/'stun-approach.jar') as old,zipfile.ZipFile(W/'mod-auto-dibuon.jar','w',zipfile.ZIP_DEFLATED) as new:
 for info in old.infolist():new.writestr(info,(W/'classes/mod/TradeSessionGuard.class').read_bytes() if info.filename=='mod/TradeSessionGuard.class' else old.read(info.filename))
print('V5: original healthy routing restored; stunned-animal approach before low-HP replacement.')
