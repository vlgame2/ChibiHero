from pathlib import Path
import importlib.util,struct,json,hashlib,io,zipfile,re
import dnfile
from dncil.cil.body.reader import read_method_body_from_bytes

ROOT=Path('/workspace/tool-review');WORK=ROOT/'server-fix'
BASE=ROOT/'output/HSO_BUG_STUN_HOI_SINH_0S_V2_THU_NGHIEM/AppManager.exe'
helper_path=next((ROOT/'target').rglob('MA_NGUON/patch_servers.py'))
spec=importlib.util.spec_from_file_location('reviewed_il_tools',helper_path);h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
U=lambda v:struct.pack('<I',v&0xffffffff)
raw=BASE.read_bytes();assert hashlib.sha256(raw).hexdigest()=='49bb702ab93ad11e0c9e391a6c16b80e7697d3c88935b16df5f84a3451d220e4'
pe=dnfile.dnPE(data=raw);data=bytearray(raw);resources={str(x.name):x.data for x in pe.net.resources}
literals=bytearray(resources['Offline.Literals']);offsets={};pos=0
while pos<len(literals):
 n=struct.unpack_from('<I',literals,pos)[0];offsets.setdefault(literals[pos+4:pos+4+n].decode('utf8'),pos);pos=h.align(pos+4+n)
refs=json.loads((WORK/'net-literal-refs.json').read_text());formulas={}
for rid in range(5,10):
 ins=h.body_of(pe,rid).instructions
 for j,x in enumerate(ins[:-5]):
  if str(x.opcode)=='ldarg.0' and str(ins[j+1].opcode)=='ldc.i4' and str(ins[j+2].opcode)=='mul' and str(ins[j+3].opcode)=='ldc.i4' and str(ins[j+4].opcode)=='xor' and str(ins[j+5].opcode)=='starg.s':formulas[rid]=(ins[j+1].operand,ins[j+3].operand)
template=next(x for x in refs if x['helper']==5 and x['value']=='Chiến Thần')
def encoded(s,helper=5,tag=None):
 if s not in offsets:
  offsets[s]=len(literals);b=s.encode();literals.extend(U(len(b))+b);literals.extend(bytes(h.align(len(literals))-len(literals)))
 mul,mask=formulas[helper];tag=template['tag'] if tag is None else tag
 v=(tag<<30)|(offsets[s]>>2)
 return ((v^(mask&0xffffffff))*pow(mul,-1,2**32))&0xffffffff
def string(s):return b'\x20'+U(encoded(s))+b'\x28'+U(template['token'])
def ldc(v):return bytes([0x16+v]) if 0<=v<=8 else b'\x1f'+struct.pack('<b',v)
changed={};array_sites={}
known={'Chiến Thần','Rồng Lửa','Global','Global Server','Phượng Hoàng','Nhân Mã','Kỳ Lân','Kì Lân','Thiên Hà','Thách Đấu','Lậu','Bạch Hổ New'}
for rid in [219,496,2732,4513,5733,5919,6331,7581]:
 rows=sorted([x for x in refs if x['rid']==rid and x['value'] in known],key=lambda x:x['il']);assert len(rows)==10,(rid,len(rows))
 b=h.body_of(pe,rid);ins=b.instructions;first=rows[0]['il'];last=rows[-1]['il']
 ai=max(i for i,x in enumerate(ins) if str(x.opcode)=='newarr' and x.offset-b.header_size<first)
 start=ins[ai-1].offset-b.header_size;ci=next(i for i,x in enumerate(ins) if x.offset-b.header_size==last)
 assert str(ins[ci+1].opcode)=='stelem.ref';end=ins[ci+2].offset-b.header_size
 labels=[x['value'] for x in rows[:8]]+['Bạch Hổ New'];assert 'Lậu' not in labels and labels.count('Bạch Hổ New')==1
 blob=ldc(9)+b'\x8d'+U(ins[ai].operand.value)
 for i,label in enumerate(labels):blob+=b'\x25'+ldc(i)+string(label)+b'\xa2'
 changed[rid]=h.rewrite(pe,rid,(start,end,blob));array_sites[rid]=labels
lower=0x0a000397;contains=0x0a000318;eq=0x0a0000dc
string_type=next(0x01000000+i for i,t in enumerate(pe.net.mdtables.TypeRef.rows,1) if str(t.TypeName)=='String' and str(t.TypeNamespace)=='System')
def aliases(il,arg,old='old'):
 # Caller first verifies this is a string. Numeric aliases only apply to a
 # server collection, avoiding unrelated numeric dropdowns.
 for s in ['lậu','bạch hổ','bach ho']:
  il.emit(bytes([arg])+b'\x74'+U(string_type)+b'\x6f'+U(lower)+string(s)+b'\x6f'+U(contains));il.branch(0x3a,'match')
 for s in ['8','9']:
  il.emit(bytes([arg])+string(s)+b'\x28'+U(eq));il.branch(0x3a,'match')
 il.branch(0x38,old)
for rid in [531,5731]:
 arg=0x03 if rid==531 else 0x02
 il=h.IL();il.emit(bytes([arg]));il.branch(0x39,'old');aliases(il,arg)
 il.label('match');il.emit(string('8')+b'\x2a');il.label('old')
 changed[rid]=h.rewrite(pe,rid,prefix=il.end())
il=h.IL();il.emit(b'\x02');il.branch(0x39,'old');aliases(il,0x02)
il.label('match');il.emit(string('Bh New')+b'\x2a');il.label('old')
changed[4509]=h.rewrite(pe,4509,prefix=il.end())
for rid in [230,2869,6013,7612,8933]:
 il=h.IL()
 il.emit(b'\x02'+string('Bạch Hổ New')+b'\x6f'+U(0x0a00032b));il.branch(0x39,'old')
 il.emit(b'\x03\x75'+U(string_type));il.branch(0x39,'old')
 aliases(il,0x03)
 il.label('match');il.emit(b'\x02'+string('Bạch Hổ New')+b'\x6f'+U(0x0a000101)+b'\x2a');il.label('old')
 changed[rid]=h.rewrite(pe,rid,prefix=il.end())
assert len(literals)==len(resources['Offline.Literals']),'Unexpected literal-table growth requires initializer update'
resources['Offline.Literals']=bytes(literals)

with zipfile.ZipFile(io.BytesIO(resources['Runtime.dat'])) as z:items=[(i,z.read(i)) for i in z.infolist()]
core=(WORK/'core-bachho8.jar').read_bytes();manifest=next(b for i,b in items if i.filename=='runtime.manifest').decode()
with zipfile.ZipFile(io.BytesIO(core)) as z:class_count=sum(n.endswith('.class') for n in z.namelist())
for key,value in [('plain_size',str(len(core))),('plain_sha256',hashlib.sha256(core).hexdigest()),('offline_source_sha256',hashlib.sha256(core).hexdigest()),('class_count',str(class_count))]:
 manifest,n=re.subn(r'(?m)^bundle\.0\.'+key+r'=[^\r\n]*','bundle.0.'+key+'='+value,manifest);assert n==1
buf=io.BytesIO()
with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
 for info,b in items:z.writestr(info,core if info.filename=='bundles/core.jar' else manifest.encode() if info.filename=='runtime.manifest' else b)
resources['Runtime.dat']=buf.getvalue()

last=pe.sections[-1];assert last.PointerToRawData+last.SizeOfRawData==len(data)
rva=last.VirtualAddress+last.SizeOfRawData;section=bytearray()
for rid,body in sorted(changed.items()):
 section.extend(bytes(h.align(len(section))-len(section)))
 struct.pack_into('<I',data,pe.net.mdtables.MethodDef.rows[rid-1].struct.get_file_offset(),rva+len(section));section.extend(body)
section.extend(bytes(h.align(len(section))-len(section)));res_start=len(section)
for row in pe.net.mdtables.ManifestResource.rows:
 struct.pack_into('<I',data,row.struct.get_file_offset(),len(section)-res_start)
 b=resources[str(row.Name)];section.extend(U(len(b))+b);section.extend(bytes(h.align(len(section))-len(section)))
struct.pack_into('<I',data,pe.net.struct.get_field_absolute_offset('ResourcesRva'),rva+res_start)
struct.pack_into('<I',data,pe.net.struct.get_field_absolute_offset('ResourcesSize'),len(section)-res_start)
size=h.align(len(section),pe.OPTIONAL_HEADER.FileAlignment)
for field,value in [('Misc_VirtualSize',last.SizeOfRawData+len(section)),('SizeOfRawData',last.SizeOfRawData+size),('Characteristics',(last.Characteristics&~0x02000000)|0x60000040)]:struct.pack_into('<I',data,last.get_field_absolute_offset(field),value)
struct.pack_into('<I',data,pe.OPTIONAL_HEADER.get_field_absolute_offset('SizeOfImage'),h.align(rva+len(section),pe.OPTIONAL_HEADER.SectionAlignment))
struct.pack_into('<I',data,pe.OPTIONAL_HEADER.get_field_absolute_offset('SizeOfInitializedData'),pe.OPTIONAL_HEADER.SizeOfInitializedData+size)
data.extend(section+bytes(size-len(section)));final=dnfile.dnPE(data=bytes(data));struct.pack_into('<I',data,final.OPTIONAL_HEADER.get_field_absolute_offset('CheckSum'),final.generate_checksum())
(WORK/'AppManager.exe').write_bytes(data)
report={'base_sha256':hashlib.sha256(raw).hexdigest(),'sha256':hashlib.sha256(data).hexdigest(),'name':'Bạch Hổ New','server_id':8,'removed_old_server_id':9,'host':'103.77.166.204','port':19129,'array_sites':array_sites,'changed_dotnet_methods':sorted(changed),'trade_v2_jar_preserved':True,'live_game_tested':False}
(WORK/'server-patch-manifest.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('Patched .NET methods:',sorted(changed),'bytes:',len(data),'SHA256:',report['sha256'])
