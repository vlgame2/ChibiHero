from pathlib import Path
import dnfile,zipfile,io,json,hashlib,shutil
from dncil.cil.body.reader import read_method_body_from_bytes
R=Path('/workspace/tool-review');W=R/'server-fix';exe=W/'AppManager.exe';base=R/'output/HSO_BUG_STUN_HOI_SINH_0S_V2_THU_NGHIEM/AppManager.exe'
report=json.loads((W/'server-patch-manifest.json').read_text());a=dnfile.dnPE(str(base));b=dnfile.dnPE(str(exe));expected=set(report['changed_dotnet_methods']);actual=[]
assert len(a.net.mdtables.MethodDef.rows)==len(b.net.mdtables.MethodDef.rows)
for rid,(old,new) in enumerate(zip(a.net.mdtables.MethodDef.rows,b.net.mdtables.MethodDef.rows),1):
 assert old.Name.value==new.Name.value and old.Signature.value==new.Signature.value
 if not old.Rva:assert not new.Rva;continue
 x=read_method_body_from_bytes(a.get_data(old.Rva));y=read_method_body_from_bytes(b.get_data(new.Rva))
 if x.raw_bytes!=y.raw_bytes:actual.append(rid)
 bounds={i.offset for i in y.instructions}
 for ins in y.instructions:
  kind=ins.opcode.operand_type.name
  if kind in ('InlineBrTarget','ShortInlineBrTarget'):assert ins.operand in bounds,(rid,ins)
  if kind=='InlineSwitch':assert all(t in bounds for t in ins.operand),(rid,ins)
 relative={v-y.header_size for v in bounds}|{y.code_size}
 for eh in y.exception_handlers:assert all(p in relative for p in [eh.try_start,eh.try_end,eh.handler_start,eh.handler_end]),rid
assert set(actual)==expected,(actual,expected)
ra={str(r.name):r.data for r in a.net.resources};rb={str(r.name):r.data for r in b.net.resources}
for name in ['Offline.Host','Offline.Literals','Launcher.jar']:assert ra[name]==rb[name],name
with zipfile.ZipFile(io.BytesIO(ra['Runtime.dat'])) as za,zipfile.ZipFile(io.BytesIO(rb['Runtime.dat'])) as zb:
 assert za.namelist()==zb.namelist() and zb.testzip() is None
 jars=[n for n in za.namelist() if n.endswith('.jar')];assert len(jars)==14
 for n in jars:
  if n!='bundles/core.jar':assert za.read(n)==zb.read(n),n
 core=zb.read('bundles/core.jar');manifest=dict(l.split('=',1) for l in zb.read('runtime.manifest').decode().splitlines() if '=' in l)
 assert hashlib.sha256(core).hexdigest()==manifest['bundle.0.plain_sha256']==manifest['bundle.0.offline_source_sha256']
 assert len(core)==int(manifest['bundle.0.plain_size'])
 with zipfile.ZipFile(io.BytesIO(za.read('bundles/core.jar'))) as j1,zipfile.ZipFile(io.BytesIO(core)) as j2:
  assert set(j2.namelist())-set(j1.namelist())=={'mod/BachHoServerPolicy.class'}
  assert sum(n.endswith('.class') for n in j2.namelist())==int(manifest['bundle.0.class_count'])
  for n in ['mod/TradeFastBridge.class','mod/lI1Il1lll1I1II1.class','mod/lliiil1IlIIillIII.class','IIlIiIliiiillIi1lilii1lill1I/IIIIliIilIIili1I1l11.class']:assert j1.read(n)==j2.read(n),n
result={'status':'PASS','changed_dotnet_methods':actual,'all_branch_and_exception_boundaries_valid':True,'offline_host_unchanged':True,'launcher_unchanged':True,'literal_table_unchanged':True,'trade_v2_jar_byte_identical':True,'trade_fast_bridge_unchanged':True,'remote_rescue_stubs_unchanged':True,'java_regression_checks':74,'dotnet_mapper_and_dropdown_checks':84,'server_id':8,'host':'103.77.166.204','port':19129,'windows_gui_tested':False,'live_game_tested':False}
(W/'v3-validation.json').write_text(json.dumps(result,indent=2)+'\n')
readme='''BẢN V3 THỬ NGHIỆM — BẠCH HỔ NEW THAY MỤC LẬU

Dùng với Tool_HSO_Bach_Ho_New_FIX_CLR_DAY_DU hoặc bản vá V2 trước đó.
1. Đóng AppManager và các tab game của tool đó bình thường.
2. Sao chép thư mục tool đích thành thư mục thử riêng để giữ bản cũ.
3. Giải nén gói này, chép AppManager.exe vào thư mục thử rồi mở từ đó.

Máy chủ: mục Lậu ở vị trí 8 đổi thành Bạch Hổ New, IP 103.77.166.204,
cổng 19129. Xóa mục Bạch Hổ New thêm riêng ở vị trí 9, danh sách còn 9 mục.
Lựa chọn/tài khoản cũ mang tên Bạch Hổ New, Lậu hoặc chỉ số 9 được ánh xạ về 8.
Không sửa/xóa dữ liệu tài khoản. Danh sách/cache cũ không ghi đè địa chỉ Bạch Hổ
khi quay về sảnh hoặc đăng nhập lại. Trong tool, chọn Bạch Hổ New để thử.

Giữ bản vá V2: hồi sinh đi buôn không thêm khoảng chờ ở mọi yêu cầu/thử lại;
nhánh thay thú nhanh vẫn cần một lần xác nhận/thả thú bình thường mỗi phiên.

Đã tái hiện lỗi vượt chỉ số trong trình đọc cache V2 khi giữ máy chủ 9 với cache
ngắn; bản sửa đạt 74 kiểm tra Java với giao diện/mạng giả lập, 14 class đã kiểm
ASM/JVM, và 84 kiểm tra bộ ánh xạ/danh sách .NET bằng trình diễn giải CIL giới hạn.
Chưa chạy GUI Windows hoặc đăng nhập server thật. Thời gian mạng/server xử lý
không được bảo đảm bằng 0. Đây là bản để thử và phản hồi, không phải kết quả
xác nhận hết lỗi trong game thật.
'''
meta={**report,'version':'V3_BACH_HO_SLOT8','validation':result}
archive=R/'output/BAN_VA_BACH_HO_NEW_V3.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 z.write(exe,'AppManager.exe');z.writestr('DOC_TRUOC.txt',readme);z.writestr('PATCH_MANIFEST.json',json.dumps(meta,ensure_ascii=False,indent=2)+'\n')
 for name in ['baseline-repro.log','reconnect-tests.log','manager-mapping-tests.json','v3-validation.json']:z.write(W/name,'KIEM_THU/'+name)
 for p in (W/'src').glob('*.java'):z.write(p,'MA_NGUON/'+p.name)
 for name in ['patch_manager_servers.py','test_manager_il.py','package_v3.py']:z.write(W/name,'MA_NGUON/'+name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and hashlib.sha256(z.read('AppManager.exe')).hexdigest()==report['sha256']
print(json.dumps(result));print('Artifact:',archive,'bytes:',archive.stat().st_size,'SHA256:',hashlib.sha256(archive.read_bytes()).hexdigest())
