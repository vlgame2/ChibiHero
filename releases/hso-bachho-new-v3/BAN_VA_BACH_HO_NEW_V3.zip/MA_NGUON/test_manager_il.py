"""Bounded CIL interpretation of string/index mapping; never launches the EXE."""
from pathlib import Path
import json,struct
import dnfile
from dncil.cil.body.reader import read_method_body_from_bytes
W=Path('/workspace/tool-review/server-fix');pe=dnfile.dnPE(str(W/'AppManager.exe'))
literal=next(r.data for r in pe.net.resources if str(r.name)=='Offline.Literals');forms={};cache={}
for rid in range(5,10):
 ins=read_method_body_from_bytes(pe.get_data(pe.net.mdtables.MethodDef.rows[rid-1].Rva)).instructions
 for j,x in enumerate(ins[:-5]):
  if str(x.opcode)=='ldarg.0' and str(ins[j+2].opcode)=='mul' and str(ins[j+4].opcode)=='xor':forms[rid]=(ins[j+1].operand,ins[j+3].operand)
def i32(v):v&=0xffffffff;return v-0x100000000 if v&0x80000000 else v
def deref(v):return v[1].get(v[2],0) if isinstance(v,tuple) and v[0]=='ref' else v
def body(rid):
 if rid not in cache:
  b=read_method_body_from_bytes(pe.get_data(pe.net.mdtables.MethodDef.rows[rid-1].Rva));cache[rid]=(b,{i.offset:j for j,i in enumerate(b.instructions)})
 return cache[rid]
def run(rid,args,depth=0):
 assert depth<12
 b,index=body(rid);pc=0;stack=[];locals={}
 for step in range(50000):
  x=b.instructions[pc];op=str(x.opcode);v=getattr(x.operand,'value',x.operand);pc+=1
  if op=='nop':continue
  if op.startswith('ldarg.'):
   stack.append(args[int(op.rsplit('.',1)[1])]);continue
  if op.startswith('ldc.i4'):
   if op in ('ldc.i4','ldc.i4.s'):stack.append(v)
   else:stack.append(-1 if op.endswith('m1') else int(op.rsplit('.',1)[1]))
   continue
  if op.startswith('stloc.'):
   locals[int(op.rsplit('.',1)[1])]=stack.pop();continue
  if op=='ldloca.s':stack.append(('ref',locals,x.operand.index));continue
  if op.startswith('ldloc.'):
   stack.append(locals.get(int(op.rsplit('.',1)[1]),0));continue
  if op=='dup':stack.append(stack[-1]);continue
  if op=='pop':stack.pop();continue
  if op in ('xor','mul','add','sub','rem.un'):
   right=stack.pop();left=stack.pop()
   stack.append((left&0xffffffff)%(right&0xffffffff) if op=='rem.un' else i32(left^right) if op=='xor' else i32(left*right) if op=='mul' else i32(left+right) if op=='add' else i32(left-right));continue
  if op in ('br','br.s'):pc=index[v];continue
  if op in ('brtrue','brtrue.s','brfalse','brfalse.s'):
   yes=bool(stack.pop());yes=yes if op.startswith('brtrue') else not yes
   if yes:pc=index[v]
   continue
  if op in ('bge.s','bge','blt.s','blt','beq.s','bne.un.s'):
   right=stack.pop();left=stack.pop();yes=left>=right if op.startswith('bge') else left<right if op.startswith('blt') else left==right if op.startswith('beq') else left!=right
   if yes:pc=index[v]
   continue
  if op=='switch':
   n=stack.pop()
   if 0<=n<len(x.operand):pc=index[x.operand[n]]
   continue
  if op in ('isinst','castclass'):
   value=stack.pop();stack.append(value if isinstance(value,str) else None);continue
  if op=='ldsfld':stack.append([None]*9);continue
  if op=='ldlen':stack.append(len(stack.pop()));continue
  if op=='conv.i4':stack.append(i32(stack.pop()));continue
  if op in ('call','callvirt'):
   table=v>>24;row=v&0xffffff
   if table==43:
    helper=pe.net.mdtables.MethodSpec.rows[row-1].Method.row_index;mul,mask=forms[helper];value=stack.pop();d=((value*mul)^mask)&0xffffffff;off=(d&0x3fffffff)<<2;n=struct.unpack_from('<I',literal,off)[0];stack.append(literal[off+4:off+4+n].decode());continue
   if table==6:
    target=pe.net.mdtables.MethodDef.rows[row-1];sig=target.Signature.value;n=sig[1]+(0 if target.Flags.mdStatic else 1);a=[stack.pop() for _ in range(n)][::-1];stack.append(run(row,a,depth+1));continue
   assert table==10,hex(v)
   target=pe.net.mdtables.MemberRef.rows[row-1];sig=target.Signature.value;name=str(target.Name);cl=str(getattr(target.Class.row,'TypeName',''));n=sig[1]+(1 if sig[0]&0x20 else 0);a=[stack.pop() for _ in range(n)][::-1]
   if name=='ToLowerInvariant' or name=='ToLower':result=a[0].lower()
   elif name=='Trim':result=a[0].strip()
   elif name=='IsNullOrEmpty':result=a[0] is None or a[0]==''
   elif name in ('Contains','op_Equality','Equals','IndexOf'):
    result=(a[1] in a[0]) if name=='Contains' else (a[0]==a[1]) if name in ('op_Equality','Equals') else a[0].index(a[1]) if a[1] in a[0] else -1
   elif name=='TryParse':
    try:value=int(a[0]);result=-(2**31)<=value<2**31
    except (ValueError,TypeError):value=0;result=False
    a[1][1][a[1][2]]=value if result else 0
   elif name=='ToString':result=str(deref(a[0]))
   else:raise AssertionError(('Unapproved member',rid,hex(v),cl,name))
   stack.append(result);continue
  if op=='ret':return stack.pop() if stack else None
  raise AssertionError((rid,op,v))
 raise AssertionError(('Instruction budget',rid))

checks=0
def check(ok,label):
 global checks
 checks+=1
 if not ok:raise AssertionError(label)
labels=['Chiến Thần','Rồng Lửa','Global Server','Phượng Hoàng','Nhân Mã','Kì Lân','Thiên Hà','Thách Đấu','Bạch Hổ New']
for rid in [531,5731]:
 for i,name in enumerate(labels):check(run(rid,[None,name] if rid==531 else [name])==str(i),(rid,name))
 for name in ['Bạch Hổ New','BẠCH HỔ NEW','bach ho','Lậu','8','9']:
  check(run(rid,[None,name] if rid==531 else [name])=='8',(rid,name))
for name in ['Bạch Hổ New','BẠCH HỔ NEW','bach ho','Lậu','8','9']:check(run(4509,[name])=='Bh New',('short',name))
for rid in [230,2869,6013,7612,8933]:
 for name in ['Bạch Hổ New','Lậu','8','9','BẠCH HỔ NEW']:check(run(rid,[labels,name])==8,(rid,name))
 check(run(rid,[labels,'Chiến Thần'])==0,(rid,'Other server'))
 check(run(rid,[['8','9'],'8'])==0,(rid,'Unrelated dropdown'))
 check(run(rid,[['8','9'],'9'])==1,(rid,'Unrelated dropdown 9'))
for rid in [219,496,2732,4513,5733,5919,6331,7581]:
 b,_=body(rid);ops=b.instructions;found=None
 for k,x in enumerate(ops):
  if str(x.opcode)!='newarr':continue
  token=x.operand.value
  if token>>24!=1 or str(pe.net.mdtables.TypeRef.rows[(token&0xffffff)-1].TypeName) not in ('String','Object'):continue
  before=ops[k-1]
  if str(before.opcode) not in ('ldc.i4','ldc.i4.s') or before.operand!=9:continue
  s=[[None]*9]
  for y in ops[k+1:]:
   op=str(y.opcode);v=getattr(y.operand,'value',y.operand)
   if op=='dup':s.append(s[-1])
   elif op.startswith('ldc.i4'):s.append(v if op in ('ldc.i4','ldc.i4.s') else int(op.rsplit('.',1)[1]))
   elif op=='call':
    spec=pe.net.mdtables.MethodSpec.rows[(v&0xffffff)-1];mul,mask=forms[spec.Method.row_index];arg=s.pop();d=((arg*mul)^mask)&0xffffffff;off=(d&0x3fffffff)<<2;n=struct.unpack_from('<I',literal,off)[0];s.append(literal[off+4:off+4+n].decode())
   elif op=='stelem.ref':
    value=s.pop();i=s.pop();array=s.pop();array[i]=value
    if all(isinstance(v,str) for v in s[0]):found=s[0];break
   else:raise AssertionError(('Unexpected array-builder instruction',rid,op))
  if found is not None:break
 expected=json.loads((W/'server-patch-manifest.json').read_text())['array_sites'][str(rid)]
 check(found==expected and len(found)==9 and found.count('Bạch Hổ New')==1 and 'Lậu' not in found,('Server dropdown',rid))
report={'status':'PASS','bounded_cil_mapper_checks':checks,'windows_gui_tested':False,'live_game_tested':False}
(W/'manager-mapping-tests.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
