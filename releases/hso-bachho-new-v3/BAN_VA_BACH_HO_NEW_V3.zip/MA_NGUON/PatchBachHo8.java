import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.util.*;
import java.util.jar.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

public final class PatchBachHo8 implements Opcodes {
    static final String P="IIlIiIliiiillIi1lilii1lill1I/",T=P+"l1I1I1IIi1iI1Ili1IlI1lllIIli",W=P+"IIIiilililIilIli",C=P+"l1llI1l1iIi1iii11lil",R=P+"IIi1l11l1111iI1ll111ll";
    static final String F="IIlIiIliiiillIi1lilii1lill1I",S="l1lli1lIliIiiiIliIilII",CONTROL="mod/iIililIIl1iIli",POLICY="mod/BachHoServerPolicy";
    static int rows=0,ports=0,sizes=0,labels=0,hosts=0,guards=0,normalizations=0,connects=0,helpers=0;
    static ClassLoader hierarchy;
    static boolean selected(FieldInsnNode f){return (f.owner.equals(W)&&f.name.equals("lliiil1IlIIillIII")&&f.desc.equals("B"))||(f.owner.equals(CONTROL)&&f.name.equals("IliIl1i11Ilii1li1II1iIl")&&f.desc.equals("I"));}
    static AbstractInsnNode next(AbstractInsnNode n){do{n=n.getNext();}while(n!=null&&n.getOpcode()<0);return n;}
    static AbstractInsnNode prev(AbstractInsnNode n){do{n=n.getPrevious();}while(n!=null&&n.getOpcode()<0);return n;}
    static void removeOps(MethodNode m,AbstractInsnNode start,int count){
        AbstractInsnNode n=start;
        for(int i=0;i<count;i++){AbstractInsnNode following=next(n);m.instructions.remove(n);n=following;}
    }
    static void ensureBody(MethodNode m){
        m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();
        for(String f:new String[]{F,S}){
            m.instructions.add(new FieldInsnNode(GETSTATIC,T,f,"[[Ljava/lang/String;"));
            m.instructions.add(new MethodInsnNode(INVOKESTATIC,POLICY,"rows","([[Ljava/lang/String;)[[Ljava/lang/String;",false));
            m.instructions.add(new FieldInsnNode(PUTSTATIC,T,f,"[[Ljava/lang/String;"));
        }
        for(String f:new String[]{"IIIiilililIilIli","Iliill11lliiIIII1l1i1"}){
            m.instructions.add(new FieldInsnNode(GETSTATIC,W,f,"[I"));
            m.instructions.add(new MethodInsnNode(INVOKESTATIC,POLICY,f.equals("IIIiilililIilIli")?"ports":"languages","([I)[I",false));
            m.instructions.add(new FieldInsnNode(PUTSTATIC,W,f,"[I"));
        }
        m.instructions.add(new InsnNode(RETURN));helpers++;
    }
    static byte[] patch(byte[] data){
        ClassNode c=new ClassNode();new ClassReader(data).accept(c,ClassReader.SKIP_FRAMES);boolean changed=false;
        for(MethodNode m:c.methods){
            if(c.name.equals(T)&&m.name.equals("hsoEnsureBachHo")&&m.desc.equals("()V")){ensureBody(m);changed=true;}
            if((c.name.equals(T)||c.name.equals(W))&&m.name.equals("<clinit>")){
                for(AbstractInsnNode n:m.instructions.toArray()){
                    if(n.getPrevious()==null&&n!=m.instructions.getFirst())continue;
                    if(n instanceof IntInsnNode&&((IntInsnNode)n).operand==9&&prev(n)!=null&&prev(n).getOpcode()==DUP){
                        AbstractInsnNode following=next(n);
                        if(c.name.equals(T)&&following.getOpcode()==ICONST_2&&next(following) instanceof TypeInsnNode){
                            removeOps(m,prev(n),13);rows++;changed=true;continue;
                        }
                        if(c.name.equals(W)&&following instanceof IntInsnNode&&((IntInsnNode)following).operand==19129&&next(following).getOpcode()==IASTORE){
                            removeOps(m,prev(n),4);ports++;changed=true;continue;
                        }
                    }
                    if(n instanceof IntInsnNode&&((IntInsnNode)n).operand==10&&next(n) instanceof MethodInsnNode){
                        MethodInsnNode call=(MethodInsnNode)next(n);
                        if(call.owner.equals("java/util/Arrays")&&call.name.equals("copyOf")){((IntInsnNode)n).operand=9;sizes++;changed=true;}
                    }
                    if(c.name.equals(T)&&n instanceof LdcInsnNode){
                        LdcInsnNode l=(LdcInsnNode)n;
                        if("Lậu".equals(l.cst)){l.cst="Bạch Hổ New";labels++;changed=true;}
                        if("legacy-private.invalid".equals(l.cst)){l.cst="103.77.166.204";hosts++;changed=true;}
                    }
                }
            }
            boolean guard=(c.name.equals(C)&&m.name.equals(F)&&m.desc.equals("(Ljava/lang/String;Z)V"))||(c.name.equals(R)&&m.name.equals(F)&&m.desc.equals("()V"));
            if(guard){
                InsnList i=new InsnList();LabelNode normal=new LabelNode();
                i.add(new LdcInsnNode("game.server"));i.add(new MethodInsnNode(INVOKESTATIC,"java/lang/System","getProperty","(Ljava/lang/String;)Ljava/lang/String;",false));
                i.add(new FieldInsnNode(GETSTATIC,W,"lliiil1IlIIillIII","B"));
                i.add(new MethodInsnNode(INVOKESTATIC,POLICY,"protect","(Ljava/lang/String;I)Z",false));i.add(new JumpInsnNode(IFEQ,normal));
                i.add(new MethodInsnNode(INVOKESTATIC,T,"hsoEnsureBachHo","()V",false));i.add(new InsnNode(RETURN));i.add(normal);
                m.instructions.insert(i);guards++;changed=true;
            }
            if(c.name.equals(W)&&m.name.equals("i1iIi1lI1lii1i1lll1iil11")&&m.desc.equals("()V")){
                m.instructions.insert(new MethodInsnNode(INVOKESTATIC,T,"hsoEnsureBachHo","()V",false));connects++;changed=true;
            }
            for(AbstractInsnNode n:m.instructions.toArray())if(n instanceof FieldInsnNode&&selected((FieldInsnNode)n)){
                FieldInsnNode f=(FieldInsnNode)n;InsnList norm=new InsnList();norm.add(new MethodInsnNode(INVOKESTATIC,POLICY,"normalize","(I)I",false));
                if(f.getOpcode()==PUTSTATIC){if(f.desc.equals("B"))norm.add(new InsnNode(I2B));m.instructions.insertBefore(n,norm);normalizations++;changed=true;}
                else if(f.getOpcode()==GETSTATIC){m.instructions.insert(n,norm);normalizations++;changed=true;}
            }
        }
        if(!changed)return data;
        ClassWriter writer=new ClassWriter(ClassWriter.COMPUTE_FRAMES|ClassWriter.COMPUTE_MAXS){
            protected String getCommonSuperClass(String a,String b){try{
                Class<?> x=Class.forName(a.replace('/','.'),false,hierarchy),y=Class.forName(b.replace('/','.'),false,hierarchy);
                if(x.isAssignableFrom(y))return a;if(y.isAssignableFrom(x))return b;if(x.isInterface()||y.isInterface())return "java/lang/Object";
                do{x=x.getSuperclass();}while(!x.isAssignableFrom(y));return x.getName().replace('.','/');
            }catch(Exception ex){throw new IllegalStateException(a+" / "+b,ex);}}
        };c.accept(writer);return writer.toByteArray();
    }
    public static void main(String[] args)throws Exception{
        List<URL> urls=new ArrayList<URL>();try(DirectoryStream<Path> ds=Files.newDirectoryStream(Paths.get(args[2]),"*.jar")){for(Path p:ds)urls.add(p.toUri().toURL());}
        hierarchy=new URLClassLoader(urls.toArray(new URL[0]),PatchBachHo8.class.getClassLoader());
        int changes=0;
        try(JarFile in=new JarFile(args[0]);JarOutputStream out=new JarOutputStream(Files.newOutputStream(Paths.get(args[1])))){
            Enumeration<JarEntry> en=in.entries();while(en.hasMoreElements()){
                JarEntry e=en.nextElement();ByteArrayOutputStream buf=new ByteArrayOutputStream();try(InputStream s=in.getInputStream(e)){byte[] b=new byte[16384];int n;while((n=s.read(b))!=-1)buf.write(b,0,n);}
                byte[] old=buf.toByteArray(),now=e.getName().endsWith(".class")?patch(old):old;if(!Arrays.equals(old,now))changes++;
                JarEntry ne=new JarEntry(e.getName());ne.setTime(e.getTime());out.putNextEntry(ne);out.write(now);out.closeEntry();
            }
            out.putNextEntry(new JarEntry(POLICY+".class"));out.write(Files.readAllBytes(Paths.get(args[3])));out.closeEntry();
        }
        if(rows!=2||ports!=1||sizes!=4||labels!=2||hosts!=2||guards!=2||connects!=1||helpers!=1||normalizations==0)throw new AssertionError("Unexpected patch counts: "+rows+","+ports+","+sizes+","+labels+","+hosts+","+guards+","+connects+","+helpers+","+normalizations);
        System.out.println("Changed core classes="+changes+"; normalized selected-server accesses="+normalizations+"; exactly nine slots, Bach Ho fixed at 8.");
    }
}
