package mod;
import java.util.Arrays;

public final class BachHoServerPolicy {
    private BachHoServerPolicy(){}
    public static int normalize(int id){return id==9?8:id;}
    public static boolean protect(String property,int selected){
        return "8".equals(property)||"9".equals(property)||normalize(selected)==8;
    }
    public static String[][] rows(String[][] input){
        String[][] result=Arrays.copyOf(input==null?new String[0][]:input,9);
        result[8]=new String[]{"Bạch Hổ New","103.77.166.204"};
        return result;
    }
    public static int[] ports(int[] input){
        int[] result=Arrays.copyOf(input==null?new int[0]:input,9);
        result[8]=19129;return result;
    }
    public static int[] languages(int[] input){
        int[] result=Arrays.copyOf(input==null?new int[0]:input,9);
        result[8]=0;return result;
    }
}
