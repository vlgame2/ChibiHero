import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.lang.reflect.*;
import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.util.CheckClassAdapter;

public final class TestBachHoReconnect implements Opcodes {
    static final String P=PatchBachHo8.P,T=PatchBachHo8.T,W=PatchBachHo8.W,C=PatchBachHo8.C,R=PatchBachHo8.R,F=PatchBachHo8.F,S=PatchBachHo8.S;
    static final String NET=P+"i1liII11l1IIi1l11III1",CTRL=PatchBachHo8.CONTROL,LANG=P+"l111IIiIl1illl1lllI";
    static int checks;
    static void check(boolean b,String why){checks++;if(!b)throw new AssertionError(why);}
    static byte[] bytes(ClassLoader l,String name)throws Exception{try(InputStream in=l.getResourceAsStream(name+".class")){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[16384];int n;while((n=in.read(b))!=-1)out.write(b,0,n);return out.toByteArray();}}
    static void constructor(ClassWriter w){MethodVisitor m=w.visitMethod(ACC_PUBLIC,"<init>","()V",null,null);m.visitCode();m.visitVarInsn(ALOAD,0);m.visitMethodInsn(INVOKESPECIAL,"java/lang/Object","<init>","()V",false);m.visitInsn(RETURN);m.visitMaxs(0,0);m.visitEnd();}
    static byte[] networkFixture(){
        ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_FRAMES|ClassWriter.COMPUTE_MAXS);w.visit(V1_8,ACC_PUBLIC,NET,null,"java/lang/Object",null);
        w.visitField(ACC_PUBLIC|ACC_STATIC,"instance","L"+NET+";",null,null).visitEnd();w.visitField(ACC_PUBLIC|ACC_STATIC,"host","Ljava/lang/String;",null,null).visitEnd();w.visitField(ACC_PUBLIC|ACC_STATIC,"port","I",null,null).visitEnd();w.visitField(ACC_PUBLIC|ACC_STATIC,"attempts","I",null,null).visitEnd();constructor(w);
        MethodVisitor m=w.visitMethod(ACC_STATIC,"<clinit>","()V",null,null);m.visitCode();m.visitTypeInsn(NEW,NET);m.visitInsn(DUP);m.visitMethodInsn(INVOKESPECIAL,NET,"<init>","()V",false);m.visitFieldInsn(PUTSTATIC,NET,"instance","L"+NET+";");m.visitInsn(RETURN);m.visitMaxs(0,0);m.visitEnd();
        m=w.visitMethod(ACC_PUBLIC|ACC_STATIC,F,"()L"+NET+";",null,null);m.visitCode();m.visitFieldInsn(GETSTATIC,NET,"instance","L"+NET+";");m.visitInsn(ARETURN);m.visitMaxs(0,0);m.visitEnd();
        m=w.visitMethod(ACC_PUBLIC,S,"()Z",null,null);m.visitCode();m.visitInsn(ICONST_0);m.visitInsn(IRETURN);m.visitMaxs(0,0);m.visitEnd();
        m=w.visitMethod(ACC_PUBLIC,F,"(Ljava/lang/String;I)V",null,null);m.visitCode();m.visitVarInsn(ALOAD,1);m.visitFieldInsn(PUTSTATIC,NET,"host","Ljava/lang/String;");m.visitVarInsn(ILOAD,2);m.visitFieldInsn(PUTSTATIC,NET,"port","I");m.visitFieldInsn(GETSTATIC,NET,"attempts","I");m.visitInsn(ICONST_1);m.visitInsn(IADD);m.visitFieldInsn(PUTSTATIC,NET,"attempts","I");m.visitInsn(RETURN);m.visitMaxs(0,0);m.visitEnd();w.visitEnd();return w.toByteArray();
    }
    static byte[] cacheStorageFixture(){
        String name=P+"i1IIIIll1i1I1Iii1i";
        ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);w.visit(V1_8,ACC_PUBLIC,name,null,"java/lang/Object",null);
        MethodVisitor m=w.visitMethod(ACC_PUBLIC|ACC_STATIC,F,"(Ljava/lang/String;[B)V",null,null);m.visitCode();m.visitInsn(RETURN);m.visitMaxs(0,0);m.visitEnd();w.visitEnd();return w.toByteArray();
    }
    static byte[] fixture(ClassLoader l,String name)throws Exception{
        ClassNode c=new ClassNode();new ClassReader(bytes(l,name)).accept(c,0);
        if(name.equals(CTRL)||name.equals(LANG)){c.methods.clear();}
        else if(name.equals(W)){
            Iterator<MethodNode> it=c.methods.iterator();while(it.hasNext()){MethodNode m=it.next();if(!m.name.equals("i1iIi1lI1lii1i1lll1iil11")||!m.desc.equals("()V"))it.remove();}
            MethodNode init=new MethodNode(ACC_STATIC,"<clinit>","()V",null,null);
            for(String f:new String[]{"IIIiilililIilIli","Iliill11lliiIIII1l1i1"}){init.instructions.add(new IntInsnNode(BIPUSH,10));init.instructions.add(new IntInsnNode(NEWARRAY,T_INT));init.instructions.add(new FieldInsnNode(PUTSTATIC,W,f,"[I"));}
            init.instructions.add(new InsnNode(RETURN));c.methods.add(init);
        }else if(name.equals(C)){
            c.superName="java/lang/Object";c.interfaces.clear();Iterator<MethodNode> it=c.methods.iterator();while(it.hasNext()){MethodNode m=it.next();if(!m.name.equals(F)||!m.desc.equals("(Ljava/lang/String;Z)V"))it.remove();}
        }
        ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);return w.toByteArray();
    }
    static class FixtureLoader extends URLClassLoader {
        Map<String,byte[]> overrides=new HashMap<String,byte[]>();FixtureLoader(URL[] urls){super(urls,null);}
        protected Class<?> findClass(String name)throws ClassNotFoundException{byte[] b=overrides.get(name.replace('.','/'));return b==null?super.findClass(name):defineClass(name,b,0,b.length);}
    }
    public static void main(String[] a)throws Exception{
        List<URL> urls=new ArrayList<URL>();urls.add(Paths.get(a[0]).toUri().toURL());try(DirectoryStream<Path> ds=Files.newDirectoryStream(Paths.get(a[1]),"*.jar")){for(Path p:ds)urls.add(p.toUri().toURL());}
        URLClassLoader production=new URLClassLoader(urls.toArray(new URL[0]),null);
        List<String> changed=new ArrayList<String>();try(java.util.jar.JarFile j=new java.util.jar.JarFile(a[0]);java.util.jar.JarFile original=new java.util.jar.JarFile(a[2])){
            Enumeration<java.util.jar.JarEntry> en=j.entries();while(en.hasMoreElements()){
                String n=en.nextElement().getName();if(!n.endsWith(".class"))continue;
                boolean different=original.getEntry(n)==null||!Arrays.equals(bytes(production,n.substring(0,n.length()-6)),read(original.getInputStream(original.getEntry(n))));
                if(!different)continue;changed.add(n);StringWriter errors=new StringWriter();CheckClassAdapter.verify(new ClassReader(bytes(production,n.substring(0,n.length()-6))),production,false,new PrintWriter(errors));
                check(errors.toString().length()==0,"ASM verification "+n+": "+errors);Class.forName(n.substring(0,n.length()-6).replace('/','.'),false,production).getDeclaredMethods();
            }
        }
        FixtureLoader loader=new FixtureLoader(urls.toArray(new URL[0]));
        for(String n:new String[]{CTRL,LANG,W,C})loader.overrides.put(n,fixture(production,n));loader.overrides.put(NET,networkFixture());loader.overrides.put(P+"i1IIIIll1i1I1Iii1i",cacheStorageFixture());
        Class<?> table=Class.forName(T.replace('/','.'),true,loader),world=Class.forName(W.replace('/','.'),true,loader),control=Class.forName(CTRL.replace('/','.'),true,loader),network=Class.forName(NET.replace('/','.'),true,loader);
        Class<?> socket=Class.forName("mod.lII1i11iIlIililIli",true,loader);Constructor<?> ctor=socket.getDeclaredConstructor();ctor.setAccessible(true);Object receiver=ctor.newInstance();Method login=socket.getDeclaredMethod(F,String.class,DataOutputStream.class);login.setAccessible(true);
        Method cache=Class.forName(C.replace('/','.'),true,loader).getMethod(F,String.class,Boolean.TYPE),reset=Class.forName(R.replace('/','.'),true,loader).getMethod(F),connect=world.getMethod("i1iIi1lI1lii1i1lll1iil11");
        if(a.length>3&&a[3].equals("baseline")){
            System.clearProperty("game.server");world.getField("lliiil1IlIIillIII").setByte(null,(byte)9);
            try{cache.invoke(null,"Old0:old0.invalid:19129:0,Old1:old1.invalid:19129:0,0",Boolean.FALSE);throw new AssertionError("Baseline did not fail");}
            catch(InvocationTargetException e){if(!(e.getCause() instanceof ArrayIndexOutOfBoundsException))throw e;System.out.println("REPRODUCED V2 defect: legacy server index 9 plus shorter lobby cache causes ArrayIndexOutOfBoundsException in actual cache parser, with UI/network/storage fixtures.");return;}
        }
        for(String property:new String[]{"8","9",null})for(int legacyId:new int[]{8,9}){
            if(property==null)System.clearProperty("game.server");else System.setProperty("game.server",property);
            for(int round=0;round<2;round++){
                login.invoke(receiver,"LOGIN|probe_user|DUMMY|"+legacyId+"|1",new DataOutputStream(new ByteArrayOutputStream()));
                check(control.getField("IliIl1i11Ilii1li1II1iIl").getInt(null)==8,"LOGIN migrates legacy server id");
                world.getField("lliiil1IlIIillIII").setByte(null,(byte)legacyId);
                cache.invoke(null,"Old0:old0.invalid:19129:0,Old1:old1.invalid:19129:0,0",Boolean.FALSE);reset.invoke(null);connect.invoke(null);
                String[][] rows=(String[][])table.getField(F).get(null);
                check(rows.length==9&&rows[8][0].equals("Bạch Hổ New")&&rows[8][1].equals("103.77.166.204"),"Cache/reset keep unique fixed slot");
                check(((String[][])table.getField(S).get(null)).length==9,"Alternate registry has nine slots");
                check(network.getField("host").get(null).equals("103.77.166.204")&&network.getField("port").getInt(null)==19129,"First/repeated connect uses correct endpoint");
                check(world.getField("lliiil1IlIIillIII").getByte(null)==8,"Selected slot normalized before reconnect");
            }
        }
        System.out.println("PASS: "+checks+" checks; "+changed.size()+" production classes ASM/JVM verified; repeated LOGIN/cache/reset/connect tested with UI/network fixtures, no live server authentication.");
    }
    static byte[] read(InputStream in)throws IOException{try(InputStream s=in){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[16384];int n;while((n=s.read(b))!=-1)out.write(b,0,n);return out.toByteArray();}}
}
