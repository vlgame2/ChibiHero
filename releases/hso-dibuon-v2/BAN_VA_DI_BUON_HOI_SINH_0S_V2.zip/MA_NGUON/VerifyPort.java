import java.nio.file.*;
import java.net.*;
import java.io.*;
import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.util.CheckClassAdapter;

public class VerifyPort {
    public static void main(String[] args)throws Exception {
        List<URL> urls=new ArrayList<URL>();
        Path patched=Paths.get(args[0]),original=Paths.get(args[1]);
        urls.add(patched.resolve("core.jar").toUri().toURL());urls.add(patched.resolve("mod-auto-dibuon.jar").toUri().toURL());
        try(DirectoryStream<Path> ds=Files.newDirectoryStream(original,"*.jar")){for(Path p:ds)urls.add(p.toUri().toURL());}
        URLClassLoader loader=new URLClassLoader(urls.toArray(new URL[0]),null);
        String[] names={"mod.ModAutoTrade","mod.ModAutoTradeV3","mod.TradeFastBridge","IIlIiIliiiillIi1lilii1lill1I.IIIIliIilIIili1I1l11"};
        for(String name:names) {
            String entry=name.replace('.','/')+".class";
            try(InputStream in=loader.getResourceAsStream(entry)) {
                StringWriter errors=new StringWriter();
                CheckClassAdapter.verify(new ClassReader(in),loader,false,new PrintWriter(errors));
                if(errors.toString().length()!=0)throw new AssertionError(errors.toString());
            }
            Class<?> c=Class.forName(name,false,loader);c.getDeclaredMethods();c.getDeclaredFields();
            System.out.println("ASM and JVM verification PASS: "+name);
        }
        Class<?> trade=Class.forName("mod.ModAutoTrade",false,loader);
        if(trade.getField("lIlIIIIIiiiiII1l1l1iII1l1").getType()!=Integer.TYPE)throw new AssertionError("Animal selection field");
        trade.getMethod("llIIilIiiiIl1lII11",new Class<?>[0]);
        trade.getDeclaredMethod("IIiillll1iI1I1il11lIli1ll",new Class<?>[0]);
        Class<?> service=Class.forName(names[3],false,loader);
        service.getMethod("l1lli1lIliIiiiIliIilII",new Class<?>[0]);
        service.getMethod("llil11il1iII1lI",new Class<?>[]{Short.TYPE,Byte.TYPE,Byte.TYPE});
        System.out.println("Actual target reflection signatures: PASS");
        java.lang.reflect.Method delay=trade.getMethod("IIlIiIliiiillIi1lilii1lill1I",new Class<?>[0]);
        java.lang.reflect.Field configured=trade.getField("llliilIillilIiiIi");
        for(int seconds:new int[]{-1,0,1,15,999}) {
            configured.setInt(null,seconds);
            if(((Long)delay.invoke(null,new Object[0])).longValue()!=0L)throw new AssertionError("Nonzero revive delay");
        }
        System.out.println("Actual delay getter: zero for all 5 configured values tested");
        int timingChecks=0;
        for(String name:new String[]{"mod/ModAutoTrade","mod/ModAutoTradeV3"}) {
            try(InputStream in=loader.getResourceAsStream(name+".class")) {
                ClassNode c=new ClassNode();new ClassReader(in).accept(c,0);int comparisons=0;
                for(MethodNode m:c.methods)for(AbstractInsnNode n:m.instructions.toArray()) {
                    if(name.endsWith("V3")&&n instanceof FieldInsnNode&&n.getOpcode()==Opcodes.PUTSTATIC&&((FieldInsnNode)n).name.equals("IIII11illI1llI11")) {
                        if(n.getPrevious().getOpcode()!=Opcodes.ICONST_0)throw new AssertionError("Nonzero jitter store");
                    }
                    if(n instanceof MethodInsnNode) {
                        MethodInsnNode call=(MethodInsnNode)n;
                        if(!call.owner.equals("mod/ModAutoTrade")||!call.name.equals("IIlIiIliiiillIi1lilii1lill1I")||!call.desc.equals("()J"))continue;
                        // Execute the actual patched cooldown expression in isolation.
                        ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_FRAMES|ClassWriter.COMPUTE_MAXS);
                        String probe="TimingProbe"+comparisons+name.substring(name.lastIndexOf('/')+1);
                        w.visit(Opcodes.V1_8,Opcodes.ACC_PUBLIC,probe,null,"java/lang/Object",null);
                        MethodVisitor v=w.visitMethod(Opcodes.ACC_PUBLIC|Opcodes.ACC_STATIC,"eligible","(JI)Z",null,null);v.visitCode();v.visitVarInsn(Opcodes.LLOAD,0);
                        AbstractInsnNode x=n;
                        while(x!=null&&x.getOpcode()!=Opcodes.LCMP) {
                            if(x instanceof FieldInsnNode&&((FieldInsnNode)x).name.equals("IIII11illI1llI11"))v.visitVarInsn(Opcodes.ILOAD,2);
                            else x.accept(v);
                            x=x.getNext();
                        }
                        if(x==null)throw new AssertionError("Revive comparison missing");
                        v.visitInsn(Opcodes.LCMP);Label no=new Label();v.visitJumpInsn(Opcodes.IFLT,no);v.visitInsn(Opcodes.ICONST_1);v.visitInsn(Opcodes.IRETURN);v.visitLabel(no);v.visitInsn(Opcodes.ICONST_0);v.visitInsn(Opcodes.IRETURN);v.visitMaxs(0,0);v.visitEnd();w.visitEnd();
                        final byte[] code=w.toByteArray();
                        class ProbeLoader extends ClassLoader {ProbeLoader(){super(loader);}Class<?> loadProbe(){return defineClass(null,code,0,code.length);}}
                        java.lang.reflect.Method eligible=new ProbeLoader().loadProbe().getMethod("eligible",Long.TYPE,Integer.TYPE);
                        for(int death=0;death<20;death++)for(long elapsed:new long[]{0L,0L,1L}) {
                            if(!((Boolean)eligible.invoke(null,Long.valueOf(elapsed),Integer.valueOf(0))).booleanValue())throw new AssertionError("Waiting on death "+death);
                            timingChecks++;
                        }
                        comparisons++;
                    }
                }
                if(comparisons!=1)throw new AssertionError("Unexpected revive-comparison count "+comparisons);
                System.out.println("Every-attempt timing check PASS: "+name);
            }
        }
        System.out.println("PASS: "+timingChecks+" actual-bytecode timing checks across repeated deaths and retries; no game/network calls.");
    }
}
