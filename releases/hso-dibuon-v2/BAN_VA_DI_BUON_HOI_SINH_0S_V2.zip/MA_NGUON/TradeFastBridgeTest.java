package mod;

import java.lang.reflect.Field;

class ModAutoTrade {
    public static int lIlIIIIIiiiiII1l1l1iII1l1;
    public static Object animal;
    public static boolean frozen;
    public static Object llIIilIiiiIl1lII11(){return animal;}
    private static void IIiillll1iI1I1il11lIli1ll(){}
}

public class TradeFastBridgeTest {
    static int count;
    static void check(boolean b,String description){count++;if(!b)throw new AssertionError(description);}
    static void set(String name,Object value)throws Exception{Field f=TradeFastBridge.class.getDeclaredField(name);f.setAccessible(true);f.set(null,value);}
    static void reset()throws Exception{set("learned",false);set("lastAnimal",null);set("firstRequest",0L);set("lastRequest",0L);set("sending",false);set("awaitingSummon",false);System.clearProperty("hso.trade.fast");ModAutoTrade.animal=null;ModAutoTrade.lIlIIIIIiiiiII1l1l1iII1l1=0;sender().reset();}
    static IIlIiIliiiillIi1lilii1lill1I.IIIIliIilIIili1I1l11 sender(){return IIlIiIliiiillIi1lilii1lill1I.IIIIliIilIIili1I1l11.l1lli1lIliIiiiIliIilII();}
    public static void main(String[] args)throws Exception{
        reset();check(!TradeFastBridge.summon(),"No unlearned menu replay");
        TradeFastBridge.observe((short)1234,(byte)4,(byte)1);check(!TradeFastBridge.summon(),"Ignore unrelated menu");
        TradeFastBridge.observe((short)1234,(byte)57,(byte)0);check(!TradeFastBridge.summon(),"Ignore cancellation");
        for(int animal=0;animal<3;animal++){
            reset();ModAutoTrade.lIlIIIIIiiiiII1l1l1iII1l1=animal;ModAutoTrade.frozen=true;ModAutoTrade.animal=new Object();
            TradeFastBridge.observe((short)1234,(byte)58,(byte)1);
            check(TradeFastBridge.replace(),"Replace frozen animal "+animal);
            check(sender().calls==1&&sender().id==1234&&sender().menu==58&&sender().choice==1,"Replacement packet fields "+animal);
            check(TradeFastBridge.replace()&&sender().calls==1,"Rate limit replacement "+animal);
            ModAutoTrade.animal=null;set("lastRequest",0L);
            check(TradeFastBridge.summon(),"Summon frozen animal "+animal);
            check(sender().menu==57&&sender().choice==1,"Summon packet fields "+animal);
            check(!TradeFastBridge.summonReady(),"No false completion before server animal update "+animal);
            ModAutoTrade.animal=new Object();
            check(TradeFastBridge.summonReady(),"Advance normal workflow after fast summon "+animal);
            check(!TradeFastBridge.summonReady(),"Consume fast-summon completion exactly once "+animal);
        }
        reset();TradeFastBridge.observe((short)4321,(byte)57,(byte)1);ModAutoTrade.animal=new Object();check(!TradeFastBridge.summon(),"Do not treat mounted as missing");
        check(TradeFastBridge.replace(),"Learned confirmation supports replace");
        set("firstRequest",System.currentTimeMillis()-6000L);check(!TradeFastBridge.replace(),"Timeout restores normal handler");
        check(!TradeFastBridge.replace(),"Timeout disables replay until normal relearning");
        reset();TradeFastBridge.observe((short)4,(byte)57,(byte)1);ModAutoTrade.lIlIIIIIiiiiII1l1l1iII1l1=3;check(!TradeFastBridge.summon(),"Only three known trade animals");
        reset();TradeFastBridge.observe((short)4,(byte)57,(byte)1);System.setProperty("hso.trade.fast","false");check(!TradeFastBridge.summon(),"Explicit disable");
        reset();TradeFastBridge.observe((short)4,(byte)57,(byte)1);sender().fail=true;check(!TradeFastBridge.summon(),"Sender failure restores original handler");
        System.out.println("PASS: "+count+" local simulated assertions; no network or game login.");
    }
}
