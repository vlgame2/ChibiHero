import java.nio.file.*;
import java.util.*;
import java.util.jar.*;
import java.io.*;
import java.net.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

public final class PortTrade implements Opcodes {
    static final String TRADE="mod/ModAutoTrade", V3="mod/ModAutoTradeV3", HELPER="mod/TradeFastBridge";
    static final String SERVICE="IIlIiIliiiillIi1lilii1lill1I/IIIIliIilIIili1I1l11";
    static final String DELAY="IIlIiIliiiillIi1lilii1lill1I";
    static int revived=0, jitterRemoved=0, replaced=0, summoned=0, observed=0, confirmed=0;
    static ClassLoader hierarchy;

    static InsnList shortcut(String name, boolean returnsBoolean) {
        InsnList i=new InsnList(); LabelNode normal=new LabelNode();
        i.add(new MethodInsnNode(INVOKESTATIC,HELPER,name,"()Z",false));
        i.add(new JumpInsnNode(IFEQ,normal));
        if(returnsBoolean)i.add(new InsnNode(ICONST_1));
        i.add(new InsnNode(returnsBoolean?IRETURN:RETURN)); i.add(normal);
        return i;
    }
    static byte[] patch(byte[] bytes) {
        ClassNode c=new ClassNode();new ClassReader(bytes).accept(c,ClassReader.SKIP_FRAMES);
        boolean changed=false;
        for(MethodNode m:c.methods) {
            if(c.name.equals(TRADE)&&m.name.equals(DELAY)&&m.desc.equals("()J")) {
                m.instructions.clear();m.tryCatchBlocks.clear();
                if(m.localVariables!=null)m.localVariables.clear();
                m.instructions.add(new InsnNode(LCONST_0));m.instructions.add(new InsnNode(LRETURN));
                revived++;changed=true;
            }
            if(c.name.equals(V3)) {
                for(AbstractInsnNode n:m.instructions.toArray())if(n instanceof FieldInsnNode) {
                    FieldInsnNode f=(FieldInsnNode)n;
                    if(f.getOpcode()==PUTSTATIC&&f.owner.equals(V3)&&f.name.equals("IIII11illI1llI11")&&f.desc.equals("I")&&n.getPrevious().getOpcode()==IADD) {
                        AbstractInsnNode begin=n.getPrevious();
                        for(int k=0;k<5;k++)begin=begin.getPrevious();
                        if(!(begin instanceof IntInsnNode)||((IntInsnNode)begin).operand!=20)throw new IllegalStateException("Unexpected jitter expression");
                        AbstractInsnNode x=begin;
                        while(x!=n){AbstractInsnNode next=x.getNext();m.instructions.remove(x);x=next;}
                        m.instructions.insertBefore(n,new InsnNode(ICONST_0));
                        jitterRemoved++;changed=true;
                    }
                }
            }
            String low=c.name.equals(TRADE)?"i1l1llIIIl11llII1i":"lII1i11iIlIililIli";
            String stop=c.name.equals(TRADE)?"IIiillll1iI1I1il11lIli1ll":"llIIilIiiiIl1lII11";
            if((c.name.equals(TRADE)||c.name.equals(V3)) && m.name.equals(low) && m.desc.equals("()V")) {
                for(AbstractInsnNode n:m.instructions.toArray())if(n instanceof MethodInsnNode) {
                    MethodInsnNode call=(MethodInsnNode)n;
                    if(call.owner.equals(c.name)&&call.name.equals(stop)&&call.desc.equals("()V")) {
                        AbstractInsnNode condition=n.getPrevious();
                        while(condition!=null && !(condition instanceof JumpInsnNode))condition=condition.getPrevious();
                        if(condition==null || condition.getOpcode()!=IF_ICMPGE)throw new IllegalStateException("Low-HP comparison changed: "+c.name);
                        m.instructions.insert(condition,shortcut("replace",false));replaced++;changed=true;
                    }
                }
            }
            if(c.name.equals(TRADE)&&m.name.equals("i1iIi1lI1lii1i1lll1iil11")&&m.desc.equals("()Z")) {
                m.instructions.insert(shortcut("summon",true));summoned++;changed=true;
            }
            if(c.name.equals(TRADE)&&m.name.equals("IIIiiiiliIl1Iiiii11")&&m.desc.equals("()Z")) {
                m.instructions.insert(shortcut("summonReady",true));confirmed++;changed=true;
            }
            if(c.name.equals(SERVICE)&&m.name.equals("llil11il1iII1lI")&&m.desc.equals("(SBB)V")) {
                InsnList i=new InsnList();i.add(new VarInsnNode(ILOAD,1));i.add(new VarInsnNode(ILOAD,2));i.add(new VarInsnNode(ILOAD,3));
                i.add(new MethodInsnNode(INVOKESTATIC,HELPER,"observe","(SBB)V",false));m.instructions.insert(i);observed++;changed=true;
            }
        }
        if(!changed)return bytes;
        ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_FRAMES|ClassWriter.COMPUTE_MAXS) {
            protected String getCommonSuperClass(String a,String b) {
                try {
                    Class<?> x=Class.forName(a.replace('/','.'),false,hierarchy);
                    Class<?> y=Class.forName(b.replace('/','.'),false,hierarchy);
                    if(x.isAssignableFrom(y))return a;
                    if(y.isAssignableFrom(x))return b;
                    if(x.isInterface()||y.isInterface())return "java/lang/Object";
                    do{x=x.getSuperclass();}while(!x.isAssignableFrom(y));
                    return x.getName().replace('.','/');
                }catch(Exception e){throw new IllegalStateException(a+" / "+b,e);}
            }
        };c.accept(w);
        return w.toByteArray();
    }
    static void jar(Path in,Path out,byte[] helper)throws Exception {
        try(JarFile z=new JarFile(in.toFile());JarOutputStream dst=new JarOutputStream(Files.newOutputStream(out))) {
            Enumeration<JarEntry> en=z.entries();
            while(en.hasMoreElements()) {
                JarEntry e=en.nextElement(); byte[] b;
                try(InputStream stream=z.getInputStream(e)){ByteArrayOutputStream buf=new ByteArrayOutputStream();byte[] tmp=new byte[16384];int n;while((n=stream.read(tmp))!=-1)buf.write(tmp,0,n);b=buf.toByteArray();}
                if(e.getName().equals(TRADE+".class")||e.getName().equals(V3+".class")||e.getName().equals(SERVICE+".class"))b=patch(b);
                JarEntry ne=new JarEntry(e.getName());ne.setTime(e.getTime());dst.putNextEntry(ne);dst.write(b);dst.closeEntry();
            }
            if(helper!=null){dst.putNextEntry(new JarEntry(HELPER+".class"));dst.write(helper);dst.closeEntry();}
        }
    }
    public static void main(String[] a)throws Exception {
        Path input=Paths.get(a[0]),out=Paths.get(a[1]);Files.createDirectories(out);
        List<URL> urls=new ArrayList<URL>();
        try(DirectoryStream<Path> paths=Files.newDirectoryStream(input,"*.jar")){for(Path p:paths)urls.add(p.toUri().toURL());}
        hierarchy=new URLClassLoader(urls.toArray(new URL[0]),PortTrade.class.getClassLoader());
        jar(input.resolve("core.jar"),out.resolve("core.jar"),Files.readAllBytes(Paths.get(a[2])));
        jar(input.resolve("mod-auto-dibuon.jar"),out.resolve("mod-auto-dibuon.jar"),null);
        if(revived!=1||jitterRemoved!=2||replaced!=2||summoned!=1||observed!=1||confirmed!=1)throw new IllegalStateException("Patch counts "+revived+","+jitterRemoved+","+replaced+","+summoned+","+observed+","+confirmed);
        System.out.println("Patched: zero trade-revive cooldown on every attempt; both V3 jitter assignments zero; fast-trade paths retained.");
    }
}
