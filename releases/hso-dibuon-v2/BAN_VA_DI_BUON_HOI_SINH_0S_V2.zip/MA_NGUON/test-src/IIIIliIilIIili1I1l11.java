package IIlIiIliiiillIi1lilii1lill1I;

public class IIIIliIilIIili1I1l11 {
    private static final IIIIliIilIIili1I1l11 instance=new IIIIliIilIIili1I1l11();
    public int calls;
    public short id;
    public byte menu,choice;
    public boolean fail;
    public static IIIIliIilIIili1I1l11 l1lli1lIliIiiiIliIilII(){return instance;}
    public void llil11il1iII1lI(short id,byte menu,byte choice){
        if(fail)throw new IllegalStateException("simulated send failure");
        this.calls++;this.id=id;this.menu=menu;this.choice=choice;
        mod.TradeFastBridge.observe(id,menu,choice);
    }
    public void reset(){calls=0;fail=false;id=0;menu=0;choice=0;}
}
