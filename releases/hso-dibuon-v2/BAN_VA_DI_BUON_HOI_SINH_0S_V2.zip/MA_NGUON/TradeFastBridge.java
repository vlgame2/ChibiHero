package mod;

import java.lang.reflect.Method;

/** Local adaptation of the reference tool's learned trade-menu fast path. */
public final class TradeFastBridge {
    private static boolean learned;
    private static short dialog;
    private static Object lastAnimal;
    private static long firstRequest;
    private static long lastRequest;
    private static boolean sending;
    private static boolean awaitingSummon;
    private static final String SERVICE = "IIlIiIliiiillIi1lilii1lill1I.IIIIliIilIIili1I1l11";
    private static final String INSTANCE = "l1lli1lIliIiiiIliIilII";
    private static final String MENU = "llil11il1iII1lI";

    private TradeFastBridge() {}

    public static synchronized void observe(short id, byte menu, byte choice) {
        // Learn only a real normal confirmation, never our own replay.
        if (!sending && (menu == 57 || menu == 58) && choice == 1) {
            dialog = id;
            learned = true;
            lastAnimal = null;
            firstRequest = 0;
            lastRequest = 0;
            awaitingSummon = false;
        }
    }

    public static synchronized boolean replace() { return attempt(true); }
    public static synchronized boolean summon() { return attempt(false); }

    public static synchronized boolean summonReady() {
        if (!awaitingSummon) return false;
        try {
            Class<?> trade = Class.forName("mod.ModAutoTrade");
            Object animal = trade.getMethod("llIIilIiiiIl1lII11", new Class<?>[0]).invoke(null, new Object[0]);
            if (animal == null) return false;
            awaitingSummon = false;
            firstRequest = 0;
            lastRequest = 0;
            return true;
        } catch (Throwable failure) {
            awaitingSummon = false;
            return false;
        }
    }

    private static boolean attempt(boolean replacement) {
        if (!learned || "false".equalsIgnoreCase(System.getProperty("hso.trade.fast", "true"))) return false;
        try {
            Class<?> trade = Class.forName("mod.ModAutoTrade");
            int selected = trade.getField("lIlIIIIIiiiiII1l1l1iII1l1").getInt(null);
            if (selected < 0 || selected > 2) return false;
            Object animal = trade.getMethod("llIIilIiiiIl1lII11", new Class<?>[0]).invoke(null, new Object[0]);
            if (replacement != (animal != null)) return false;
            long now = System.currentTimeMillis();
            if (lastAnimal != animal || firstRequest == 0) {
                lastAnimal = animal;
                firstRequest = now;
                lastRequest = 0;
            }
            // If the server does not accept this path, restore the normal flow.
            if (now - firstRequest >= 5000L) {
                learned = false;
                awaitingSummon = false;
                return false;
            }
            Method stop = trade.getDeclaredMethod("IIiillll1iI1I1il11lIli1ll", new Class<?>[0]);
            stop.setAccessible(true);
            stop.invoke(null, new Object[0]);
            if (lastRequest != 0 && now - lastRequest < 300L) return true;
            Class<?> service = Class.forName(SERVICE);
            Object sender = service.getMethod(INSTANCE, new Class<?>[0]).invoke(null, new Object[0]);
            sending = true;
            try {
                service.getMethod(MENU, new Class<?>[]{Short.TYPE, Byte.TYPE, Byte.TYPE})
                    .invoke(sender, new Object[]{Short.valueOf(dialog), Byte.valueOf((byte)(replacement ? 58 : 57)), Byte.valueOf((byte)1)});
            } finally { sending = false; }
            lastRequest = now;
            if (!replacement) awaitingSummon = true;
            return true;
        } catch (Throwable failure) {
            learned = false;
            sending = false;
            awaitingSummon = false;
            return false;
        }
    }
}
