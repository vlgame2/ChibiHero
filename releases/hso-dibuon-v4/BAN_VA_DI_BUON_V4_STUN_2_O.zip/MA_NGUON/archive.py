from pathlib import Path
import hashlib,json,zipfile
R=Path('/workspace/tool-review');W=R/'trade-v4'
assert 'PASS:' in (W/'runtime-smoke.log').read_text()
report=json.loads((W/'validation.json').read_text());report['production_launcher_smoke_test']=True
(W/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
archive=R/'output/BAN_VA_DI_BUON_V4_STUN_2_O.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 z.write(W/'AppManager.exe','AppManager.exe');z.write(W/'README.txt','DOC_TRUOC.txt');z.write(W/'validation.json','PATCH_MANIFEST.json')
 for name in ['tests.log','runtime-smoke.log']:z.write(W/name,'KIEM_THU/'+name)
 for p in sorted((W/'src').glob('*.java')):z.write(p,'MA_NGUON/'+p.name)
 for name in ['build.py','test.py','package.py','archive.py']:z.write(W/name,'MA_NGUON/'+name)
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 assert hashlib.sha256(z.read('AppManager.exe')).hexdigest()==report['exe_sha256']
print('Artifact:',archive,'bytes:',archive.stat().st_size,'SHA256:',hashlib.sha256(archive.read_bytes()).hexdigest())
