from pathlib import Path
import subprocess
R=Path('/workspace/tool-review');W=R/'trade-v4'
cp=':'.join([str(W/'classes')]+[str(p) for p in (R/'tools').glob('asm*.jar')])
subprocess.run(['java','-jar',str(R/'tools/ecj.jar'),'-source','8','-target','8','-cp',cp,'-d',str(W/'classes'),str(W/'src/TestTradeV4.java')],check=True)
with (W/'tests.log').open('w') as out:
 p=subprocess.run(['java','-Xverify:all','-cp',cp,'TestTradeV4',str(W/'mod-auto-dibuon.jar'),str(R/'server-fix/core-bachho8.jar'),str(R/'target-resources')],stdout=out,stderr=subprocess.STDOUT,cwd=W)
print('\n'.join((W/'tests.log').read_text().splitlines()[-20:]))
raise SystemExit(p.returncode)
