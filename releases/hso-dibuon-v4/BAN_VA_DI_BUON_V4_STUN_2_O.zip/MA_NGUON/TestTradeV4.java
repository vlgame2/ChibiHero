import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;
import org.objectweb.asm.util.CheckClassAdapter;

/** Executes production update -> production guard -> production serializer.
 * UI, pathfinding, clock and network transport are fixtures. No live account. */
public final class TestTradeV4 implements Opcodes {
 static final String P=PatchTradeV4.P,T=PatchTradeV4.T,V=PatchTradeV4.V,H=PatchTradeV4.H,U=PatchTradeV4.UPDATE,D=PatchTradeV4.DELAY;
 static final String A=P+"l1l11llilI1lllIi11",C=P+"i1i11I1iil1lIl",G=P+"i1liIIii1IlIl1illlIIilIl",W=P+"IIIiilililIilIli",S=P+"IIIIliIilIIili1I1l11",B=P+"iIililIIl1iIli",PK=P+"I1lIl1l11lilIll111I11IIiIi",CLOCK="FixtureClock";
 static int checks;static URLClassLoader production;static Loader loader;
 static void check(boolean ok,String why){checks++;if(!ok)throw new AssertionError(why);}
 static byte[] read(String name)throws Exception{try(InputStream in=production.getResourceAsStream(name+".class")){if(in==null)throw new IOException(name);ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] tmp=new byte[16384];int n;while((n=in.read(tmp))!=-1)b.write(tmp,0,n);return b.toByteArray();}}
 static ClassNode node(String name)throws Exception{ClassNode c=new ClassNode();new ClassReader(read(name)).accept(c,0);return c;}
 static byte[] write(ClassNode c){ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_MAXS);c.accept(w);return w.toByteArray();}
 static MethodNode method(int access,String name,String desc){return new MethodNode(access,name,desc,null,null);}
 static void simpleReturn(MethodNode m){m.instructions.clear();m.tryCatchBlocks.clear();m.localVariables=null;Type r=Type.getReturnType(m.desc);switch(r.getSort()){case Type.VOID:m.instructions.add(new InsnNode(RETURN));break;case Type.LONG:m.instructions.add(new InsnNode(LCONST_0));m.instructions.add(new InsnNode(LRETURN));break;case Type.DOUBLE:m.instructions.add(new InsnNode(DCONST_0));m.instructions.add(new InsnNode(DRETURN));break;case Type.FLOAT:m.instructions.add(new InsnNode(FCONST_0));m.instructions.add(new InsnNode(FRETURN));break;case Type.OBJECT:case Type.ARRAY:m.instructions.add(new InsnNode(ACONST_NULL));m.instructions.add(new InsnNode(ARETURN));break;default:m.instructions.add(new InsnNode(ICONST_0));m.instructions.add(new InsnNode(IRETURN));}}
 static void ctor(ClassNode c){MethodNode m=method(ACC_PUBLIC,"<init>","()V");m.instructions.add(new VarInsnNode(ALOAD,0));m.instructions.add(new MethodInsnNode(INVOKESPECIAL,c.superName,"<init>","()V",false));m.instructions.add(new InsnNode(RETURN));c.methods.add(m);}
 static ClassNode blank(String name,String parent){ClassNode c=new ClassNode();c.version=V1_8;c.access=ACC_PUBLIC;c.name=name;c.superName=parent;return c;}
 static ClassNode stripped(String name,String parent,Set<String> kept)throws Exception{ClassNode c=node(name);c.superName=parent;c.interfaces.clear();c.access=ACC_PUBLIC;
  Iterator<MethodNode> it=c.methods.iterator();while(it.hasNext()){MethodNode m=it.next();if(m.name.startsWith("<")){it.remove();continue;}if(!kept.contains(m.name+m.desc))simpleReturn(m);}
  ctor(c);return c;}
 static void field(ClassNode c,String name,String desc){c.fields.add(new FieldNode(ACC_PUBLIC|ACC_STATIC,name,desc,null,null));}
 static Class<?> cls(String n)throws Exception{return Class.forName(n.replace('/','.'),true,loader);}
 static Field f(Class<?> c,String name)throws Exception{Field f=c.getDeclaredField(name);f.setAccessible(true);return f;}
 static void set(Class<?> c,String name,Object v)throws Exception{f(c,name).set(null,v);}
 static Object get(Class<?> c,String name)throws Exception{return f(c,name).get(null);}
 static void obj(Object o,String name,Object v)throws Exception{o.getClass().getField(name).set(o,v);}
 static Object oval(Object o,String name)throws Exception{return o.getClass().getField(name).get(o);}
 static class Loader extends URLClassLoader{Map<String,byte[]> overrides=new HashMap<String,byte[]>();Loader(URL[] u){super(u,null);}protected Class<?> findClass(String n)throws ClassNotFoundException{byte[] b=overrides.get(n.replace('.','/'));return b==null?super.findClass(n):defineClass(n,b,0,b.length);}void put(ClassNode c){overrides.put(c.name,write(c));}}
 static void fixture()throws Exception{
  loader=new Loader(production.getURLs());Set<String> empty=Collections.emptySet();
  ClassNode a=stripped(A,"java/lang/Object",empty);loader.put(a);
  ClassNode c=stripped(C,A,empty);loader.put(c);
  ClassNode world=stripped(W,"java/lang/Object",empty);loader.put(world);
  // Scene is a minimal model, with original fields so map-ID reads remain real.
  String scene=null;for(FieldNode ff:world.fields)if(ff.name.equals("IIIiiiiliIl1Iiiii11"))scene=Type.getType(ff.desc).getInternalName();loader.put(stripped(scene,"java/lang/Object",empty));
  ClassNode game=stripped(G,"java/lang/Object",empty);field(game,"fixturePath","[S");
  for(MethodNode m:game.methods){if(m.name.equals("lIlIIIIIiiiiII1l1l1iII1l1")&&m.desc.equals("()L"+G+";")){m.instructions.clear();m.instructions.add(new TypeInsnNode(NEW,G));m.instructions.add(new InsnNode(DUP));m.instructions.add(new MethodInsnNode(INVOKESPECIAL,G,"<init>","()V",false));m.instructions.add(new InsnNode(ARETURN));}
   if(m.name.equals(D)&&m.desc.equals("(IIIII)[S")){m.instructions.clear();m.instructions.add(new FieldInsnNode(GETSTATIC,G,"fixturePath","[S"));m.instructions.add(new InsnNode(ARETURN));}}
  loader.put(game);
  for(String n:new String[]{T,V}){ClassNode trade=stripped(n,"java/lang/Object",new HashSet<String>(Arrays.asList(U+"()V",D+"()J","hsoLeashStop()V")));
   if(n.equals(T)){field(trade,"fixtureAnimal","L"+A+";");for(MethodNode m:trade.methods)if(m.name.equals("llIIilIiiiIl1lII11")&&m.desc.equals("()L"+A+";")){m.instructions.clear();m.instructions.add(new FieldInsnNode(GETSTATIC,T,"fixtureAnimal","L"+A+";"));m.instructions.add(new InsnNode(ARETURN));}}
   // Make V3's ordinary runtime phase gate pass, then leave recipe ready=false.
   if(n.equals(V))for(MethodNode m:trade.methods)if(m.name.equals(D)&&m.desc.equals("(Ljava/lang/String;)Z")){m.instructions.clear();m.instructions.add(new InsnNode(ICONST_1));m.instructions.add(new InsnNode(IRETURN));}
   loader.put(trade);
  }
  for(String n:new String[]{"mod/i1liIIii1IlIl1illlIIilIl","mod/IIIiilililIilIli","mod/ModAutoKhuMuaBan","mod/illIi1ilI1IIi1iii","mod/liiI1lilIlilli11ii1Il","mod/ModAutoFarm","mod/ModAutoMove","mod/IlII11l1IIi1iI","mod/liliIl1li11l1IIilIlI1l1l"}){
   ClassNode q=stripped(n,"java/lang/Object",empty);
   if(n.equals("mod/i1liIIii1IlIl1illlIIilIl")||n.equals("mod/IIIiilililIilIli")){field(q,"fixtureFlag","Z");for(MethodNode m:q.methods)if(m.name.equals(n.endsWith("/IIIiilililIilIli")?"IliIl1i11Ilii1li1II1iIl":D)&&m.desc.equals("(Ljava/lang/String;)Z")){m.instructions.clear();m.instructions.add(new FieldInsnNode(GETSTATIC,n,"fixtureFlag","Z"));m.instructions.add(new InsnNode(IRETURN));}}
   loader.put(q);
  }
  // Use the real packet object and the real -30 serializer, replacing transport.
  ClassNode base=blank(B,"java/lang/Object");base.fields.add(new FieldNode(ACC_PUBLIC,D,"L"+PK+";",null,null));field(base,"calls","I");field(base,"payload","[B");field(base,"opcode","B");ctor(base);
  MethodNode init=method(ACC_PUBLIC,D,"(B)V");init.instructions.add(new VarInsnNode(ALOAD,0));init.instructions.add(new TypeInsnNode(NEW,PK));init.instructions.add(new InsnNode(DUP));init.instructions.add(new VarInsnNode(ILOAD,1));init.instructions.add(new MethodInsnNode(INVOKESPECIAL,PK,"<init>","(B)V",false));init.instructions.add(new FieldInsnNode(PUTFIELD,B,D,"L"+PK+";"));init.instructions.add(new VarInsnNode(ILOAD,1));init.instructions.add(new FieldInsnNode(PUTSTATIC,B,"opcode","B"));init.instructions.add(new InsnNode(RETURN));base.methods.add(init);
  MethodNode send=method(ACC_PUBLIC,D,"()V");send.instructions.add(new FieldInsnNode(GETSTATIC,B,"calls","I"));send.instructions.add(new InsnNode(ICONST_1));send.instructions.add(new InsnNode(IADD));send.instructions.add(new FieldInsnNode(PUTSTATIC,B,"calls","I"));send.instructions.add(new VarInsnNode(ALOAD,0));send.instructions.add(new FieldInsnNode(GETFIELD,B,D,"L"+PK+";"));send.instructions.add(new MethodInsnNode(INVOKEVIRTUAL,PK,D,"()[B",false));send.instructions.add(new FieldInsnNode(PUTSTATIC,B,"payload","[B"));send.instructions.add(new InsnNode(RETURN));base.methods.add(send);loader.put(base);
  ClassNode service=stripped(S,B,new HashSet<String>(Arrays.asList("l1lli1lIliIiiiIliIilII()L"+S+";","l1lli1lIliIiiiIliIilII(SBB)V")));loader.put(service);
  ClassNode clock=blank(CLOCK,"java/lang/Object");field(clock,"now","J");MethodNode nano=method(ACC_PUBLIC|ACC_STATIC,"nanoTime","()J");nano.instructions.add(new FieldInsnNode(GETSTATIC,CLOCK,"now","J"));nano.instructions.add(new InsnNode(LRETURN));clock.methods.add(nano);loader.put(clock);
  ClassNode guard=node(H);for(MethodNode m:guard.methods)for(AbstractInsnNode ins:m.instructions.toArray())if(ins instanceof MethodInsnNode){MethodInsnNode call=(MethodInsnNode)ins;if(call.owner.equals("java/lang/System")&&call.name.equals("nanoTime"))call.owner=CLOCK;}loader.put(guard);
 }
 static int calls()throws Exception{return (Integer)get(cls(B),"calls");}
 static void now(long millis)throws Exception{set(cls(CLOCK),"now",millis*1000000L);}
 static short tile(int x,int y){return (short)(x<<8|y&255);}
 static void clearEffects(Object a)throws Exception{for(String n:new String[]{"iIIIli1Ilil1Ili11lli1","liiIIil1i1iIII1i","lIi1i1li1I1llii11Iii1i1ll","Ilii1iIIIIlIil1ii","Il1IIii1lllIlIlIl1II1ii1iIl"})obj(a,n,false);}
 public static void main(String[] args)throws Exception{
  List<URL> urls=new ArrayList<URL>();urls.add(Paths.get(args[0]).toUri().toURL());urls.add(Paths.get(args[1]).toUri().toURL());try(DirectoryStream<Path> ds=Files.newDirectoryStream(Paths.get(args[2]),"*.jar")){for(Path p:ds)urls.add(p.toUri().toURL());}production=new URLClassLoader(urls.toArray(new URL[0]),null);
  for(String n:new String[]{T,V,H}){StringWriter out=new StringWriter();CheckClassAdapter.verify(new ClassReader(read(n)),production,false,new PrintWriter(out));check(out.toString().isEmpty(),"ASM "+n+": "+out);Class.forName(n.replace('/','.'),false,production).getDeclaredMethods();}
  fixture();System.setProperty("hso.trade.diagnostic","false");Class<?> trade=cls(T),v3=cls(V),guard=cls(H),game=cls(G),world=cls(W),actor=cls(A),character=cls(C);set(cls("mod/i1liIIii1IlIl1illlIIilIl"),"fixtureFlag",true);
  Object p=character.getConstructor().newInstance(),animal=actor.getConstructor().newInstance();set(game,"i1iiIi11IIilI1IiiIl11",p);Field scene=world.getField("IIIiiiiliIl1Iiiii11");scene.set(null,scene.getType().getConstructor().newInstance());
  obj(p,"ilIII1111l1i1liIil11",100);obj(animal,"ilIII1111l1i1liIil11",100);obj(animal,"Ii1lllIIl1llIiiI1i11IllI1",100);Object classic=trade.getConstructor().newInstance(),modern=v3.getConstructor().newInstance();Method tick=trade.getMethod(U),tick3=v3.getMethod(U),revive=guard.getMethod("revive",boolean.class,boolean.class),lead=guard.getMethod("beforeLead",boolean.class),fence=guard.getMethod("fence",boolean.class,boolean.class,int.class);
  for(boolean modernMode:new boolean[]{false,true}){
   set(trade,"i1iIi1lI1lii1i1lll1iil11",!modernMode);set(v3,D,modernMode);set(trade,"llliilIillilIiiIi",1);Method update=modernMode?tick3:tick;Object instance=modernMode?modern:classic;
   // General Farm revive on/off must not change ownership or delay.
   for(boolean farmOn:new boolean[]{false,true}){set(cls("mod/ModAutoFarm"),"i1l1IIll111IIi1iI111lil1i1",farmOn);
    for(int death=0;death<20;death++){
     obj(p,"IlIIl1I1IIIililIil1iiI",0);obj(p,"ilIII1111l1i1liIil11",100);revive.invoke(null,true,modernMode);now(100000+death*5000);int before=calls();obj(p,"IlIIl1I1IIIililIil1iiI",4);obj(p,"ilIII1111l1i1liIil11",0);update.invoke(instance);
     check(calls()==before+1,"Immediate dispatch on every death, mode="+modernMode+" farm="+farmOn+" death="+death);
     check(((Byte)get(cls(B),"opcode")).byteValue()==-30&&Arrays.equals((byte[])get(cls(B),"payload"),new byte[]{-1,-51,0,0}),"Real serialized in-place action");
     // Inactive module tick cannot reset the active module's timer.
     (modernMode?tick:tick3).invoke(modernMode?classic:modern);update.invoke(instance);check(calls()==before+1,"No duplicate request in same frame");now(100250+death*5000);update.invoke(instance);check(calls()==before+2,"Bounded immediate-mode retry");
    }
   }
   for(int sec=2;sec<=15;sec++){obj(p,"IlIIl1I1IIIililIil1iiI",0);obj(p,"ilIII1111l1i1liIil11",100);revive.invoke(null,true,modernMode);set(trade,"llliilIillilIiiIi",sec);now(1000000);int before=calls();obj(p,"IlIIl1I1IIIililIil1iiI",4);update.invoke(instance);now(1000000+sec*1000-1);update.invoke(instance);check(calls()==before,"Respect configured seconds "+sec);now(1000000+sec*1000);update.invoke(instance);check(calls()==before+1,"Dispatch at configured deadline "+sec);}
   obj(p,"IlIIl1I1IIIililIil1iiI",4);int before=calls();set(cls("mod/i1liIIii1IlIl1illlIIilIl"),"fixtureFlag",false);update.invoke(instance);check(calls()==before,"Retain feature gate");set(cls("mod/i1liIIii1IlIl1illlIIilIl"),"fixtureFlag",true);set(cls("mod/IIIiilililIilIli"),"fixtureFlag",true);update.invoke(instance);check(calls()==before,"Retain dungeon guard");set(cls("mod/IIIiilililIilIli"),"fixtureFlag",false);
  }
  obj(p,"IlIIl1I1IIIililIil1iiI",0);obj(p,"ilIII1111l1i1liIil11",100);obj(p,"l1IilIi1ilil1lli1I1lii1Ill",132);obj(p,"l11iliIII1ii1lilI1IlIl",132);obj(animal,"l1IilIi1ilil1lli1I1lii1Ill",132);obj(animal,"l11iliIII1ii1lilI1IlIl",132);set(trade,"fixtureAnimal",animal);
  String[] effects={"iIIIli1Ilil1Ili11lli1","liiIIil1i1iIII1i","lIi1i1li1I1llii11Iii1i1ll","Ilii1iIIIIlIil1ii","Il1IIii1lllIlIlIl1II1ii1iIl"};
  for(boolean modernMode:new boolean[]{false,true}){set(trade,"i1iIi1lI1lii1i1lll1iil11",!modernMode);set(v3,D,modernMode);set(modernMode?v3:trade,PatchTradeV4.phase(modernMode?V:T),2);
   for(String effect:effects){clearEffects(animal);obj(animal,effect,true);obj(p,"li1i1ll1liIIlIlI1IlII",new short[]{tile(5,5),tile(20,5)});(modernMode?tick3:tick).invoke(modernMode?modern:classic);check(oval(p,"li1i1ll1liIIlIlI1IlII")==null,"Actual update stops beside animal: "+effect);
    for(int i=0;i<20;i++)check((Boolean)lead.invoke(null,modernMode),"Wait persists while effect active");obj(animal,effect,false);check(!(Boolean)lead.invoke(null,modernMode),"Resume immediately after effect clear");}
   clearEffects(animal);obj(animal,effects[0],true);obj(animal,effects[1],true);lead.invoke(null,modernMode);obj(animal,effects[0],false);check((Boolean)lead.invoke(null,modernMode),"Overlapping effects wait for last effect");obj(animal,effects[1],false);check(!(Boolean)lead.invoke(null,modernMode),"Last effect clear resumes");
   // Already far away: approach the animal, keep the same path across ticks.
   obj(p,"l1IilIi1ilil1lli1I1lii1Ill",228);obj(animal,effects[0],true);short[] approach={tile(9,5),tile(8,5),tile(7,5),tile(6,5),tile(5,5)};set(game,"fixturePath",approach);check((Boolean)lead.invoke(null,modernMode),"Approach stunned animal");check(oval(p,"li1i1ll1liIIlIlI1IlII")==approach,"Obstacle-aware path requested");obj(p,"l1l1iIiIiIlIi1l11",2);lead.invoke(null,modernMode);check((Integer)oval(p,"l1l1iIiIiIlIi1l11")==2,"Approach path progress retained");obj(p,"l1IilIi1ilil1lli1I1lii1Ill",156);lead.invoke(null,modernMode);check(oval(p,"li1i1ll1liIIlIlI1IlII")==null,"Stop within one tile of stunned animal");clearEffects(animal);check(!(Boolean)lead.invoke(null,modernMode),"Resume after approach and stun clear");
   // A long queued route is clipped before leaving two tiles (48 game units).
   obj(p,"l1IilIi1ilil1lli1I1lii1Ill",132);lead.invoke(null,modernMode);obj(p,"li1i1ll1liIIlIlI1IlII",new short[]{tile(5,5),tile(6,5),tile(7,5),tile(8,5),tile(9,5)});obj(p,"l1l1iIiIiIlIi1l11",0);obj(p,"i1IiI111lIllI1lIIlI",228);obj(p,"iliI1liil1llii111Ililil",132);fence.invoke(null,true,modernMode,2);check(((short[])oval(p,"li1i1ll1liIIlIlI1IlII")).length==3,"Queued route stays within two tiles");check((Integer)oval(p,"i1IiI111lIllI1lIIlI")==0,"Distant final override removed");
   obj(p,"l1IilIi1ilil1lli1I1lii1Ill",180);check((Boolean)lead.invoke(null,modernMode),"Hold at two-tile boundary");obj(p,"l1IilIi1ilil1lli1I1lii1Ill",156);check(!(Boolean)lead.invoke(null,modernMode),"Continue once animal catches up");
  }
  // Fence must leave non-trading movement alone.
  set(trade,"i1iIi1lI1lii1i1lll1iil11",false);set(v3,D,false);short[] ordinary={tile(9,9)};obj(p,"li1i1ll1liIIlIlI1IlII",ordinary);fence.invoke(null,false,false,2);check(oval(p,"li1i1ll1liIIlIlI1IlII")==ordinary,"Disabled trading does not affect Farm/manual movement");
  System.out.println("PASS: "+checks+" assertions; production trading updates and packet serializer executed with clock/UI/path/network fixtures. No live game test.");
 }
}
