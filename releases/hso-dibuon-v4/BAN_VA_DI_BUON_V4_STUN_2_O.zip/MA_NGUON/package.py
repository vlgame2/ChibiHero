"""Replace only the trade bundle in V3; verify every other method and bundle."""
from pathlib import Path
import struct,io,re,zipfile,hashlib,json
import dnfile
from dncil.cil.body.reader import read_method_body_from_bytes
R=Path('/workspace/tool-review');W=R/'trade-v4';BASE=R/'server-fix/AppManager.exe'
sha=lambda b:hashlib.sha256(b).hexdigest()
align=lambda n,a=4:(n+a-1)//a*a
raw=BASE.read_bytes();assert sha(raw)=='9fc396f464f136fe7c786be10e6f50cfa8217dd2d398afc6e1dc4a91e45d440c'
pe=dnfile.dnPE(data=raw);resources={str(r.name):r.data for r in pe.net.resources}
with zipfile.ZipFile(io.BytesIO(resources['Runtime.dat'])) as z:items=[(i,z.read(i)) for i in z.infolist()]
trade=(W/'mod-auto-dibuon.jar').read_bytes()
with zipfile.ZipFile(io.BytesIO(trade)) as z:
 assert z.testzip() is None
 classes=sum(n.endswith('.class') for n in z.namelist())
 assert classes==5
manifest=next(b.decode() for i,b in items if i.filename=='runtime.manifest')
for key,value in [('plain_size',str(len(trade))),('plain_sha256',sha(trade)),('offline_source_sha256',sha(trade)),('class_count',str(classes))]:
 manifest,n=re.subn(r'(?m)^bundle\.6\.'+key+r'=[^\r\n]*','bundle.6.'+key+'='+value,manifest);assert n==1
runtime=io.BytesIO()
with zipfile.ZipFile(runtime,'w',zipfile.ZIP_DEFLATED) as z:
 for info,b in items:z.writestr(info,manifest.encode() if info.filename=='runtime.manifest' else trade if info.filename=='bundles/mod-auto-dibuon.jar' else b)
resources['Runtime.dat']=runtime.getvalue();(W/'Runtime.dat').write_bytes(runtime.getvalue())
data=bytearray(raw);last=pe.sections[-1];assert last.PointerToRawData+last.SizeOfRawData==len(data)
start=last.VirtualAddress+last.SizeOfRawData;section=bytearray()
for row in pe.net.mdtables.ManifestResource.rows:
 struct.pack_into('<I',data,row.struct.get_file_offset(),len(section));blob=resources[str(row.Name)];section.extend(struct.pack('<I',len(blob))+blob);section.extend(bytes(align(len(section))-len(section)))
struct.pack_into('<I',data,pe.net.struct.get_field_absolute_offset('ResourcesRva'),start)
struct.pack_into('<I',data,pe.net.struct.get_field_absolute_offset('ResourcesSize'),len(section))
extra=align(len(section),pe.OPTIONAL_HEADER.FileAlignment)
for field,value in [('Misc_VirtualSize',last.SizeOfRawData+len(section)),('SizeOfRawData',last.SizeOfRawData+extra),('Characteristics',last.Characteristics)]:struct.pack_into('<I',data,last.get_field_absolute_offset(field),value)
struct.pack_into('<I',data,pe.OPTIONAL_HEADER.get_field_absolute_offset('SizeOfImage'),align(start+len(section),pe.OPTIONAL_HEADER.SectionAlignment))
struct.pack_into('<I',data,pe.OPTIONAL_HEADER.get_field_absolute_offset('SizeOfInitializedData'),pe.OPTIONAL_HEADER.SizeOfInitializedData+extra)
data.extend(section+bytes(extra-len(section)));final=dnfile.dnPE(data=bytes(data));struct.pack_into('<I',data,final.OPTIONAL_HEADER.get_field_absolute_offset('CheckSum'),final.generate_checksum())
(W/'AppManager.exe').write_bytes(data)
assert len(pe.net.mdtables.MethodDef.rows)==len(final.net.mdtables.MethodDef.rows)
for rid,(old,new) in enumerate(zip(pe.net.mdtables.MethodDef.rows,final.net.mdtables.MethodDef.rows),1):
 assert old.Name.value==new.Name.value and old.Signature.value==new.Signature.value and old.Rva==new.Rva,rid
 if old.Rva:assert read_method_body_from_bytes(pe.get_data(old.Rva)).raw_bytes==read_method_body_from_bytes(final.get_data(new.Rva)).raw_bytes,rid
after={str(r.name):r.data for r in final.net.resources}
for name in resources:
 if name!='Runtime.dat':assert after[name]==resources[name],name
with zipfile.ZipFile(io.BytesIO(after['Runtime.dat'])) as z:
 assert z.testzip() is None
 for info,b in items:
  if info.filename not in ['runtime.manifest','bundles/mod-auto-dibuon.jar']:assert z.read(info.filename)==b,info.filename
 with zipfile.ZipFile(io.BytesIO(next(b for info,b in items if info.filename=='bundles/mod-auto-dibuon.jar'))) as old,zipfile.ZipFile(io.BytesIO(trade)) as new:
  assert set(new.namelist())-set(old.namelist())=={'mod/TradeSessionGuard.class'}
  changed=[n for n in old.namelist() if old.read(n)!=new.read(n)]
  assert set(changed)=={'mod/ModAutoTrade.class','mod/ModAutoTradeV3.class'}
assert 'PASS:' in (W/'tests.log').read_text()
report={'version':'V4_TRADE_REVIVE_LEASH_STUN','base':'V3_BACH_HO_SLOT8','base_sha256':sha(raw),'exe_sha256':sha(data),'trade_jar_sha256':sha(trade),'changed_jars':['mod-auto-dibuon.jar'],'farm_jar_byte_identical':True,'core_v3_byte_identical':True,'dotnet_method_bodies_unchanged':True,'offline_host_launcher_literals_unchanged':True,'trade_fast_bridge_unchanged':True,'revive':{'scope':'trading only','one':'first in-place request on death-detection tick','two_to_fifteen':'configured seconds','retry_floor_ms':250,'resource':'original in-place action; no currency-selection change'},'animal_distance':{'tile_size':24,'max_route_radius':48,'resume_radius':24,'stun':'wait for every movement-blocking effect to clear'},'live_game_tested':False,'windows_gui_tested':False,'tests_summary':(W/'tests.log').read_text().splitlines()[-1]}
(W/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(report,ensure_ascii=False,indent=2))
