import java.nio.file.*;
import java.util.*;
import java.util.jar.*;
import java.net.*;
import java.io.*;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

public final class PatchTradeV4 implements Opcodes {
 static final String T="mod/ModAutoTrade",V="mod/ModAutoTradeV3",H="mod/TradeSessionGuard",P="IIlIiIliiiillIi1lilii1lill1I/";
 static final String UPDATE="l1iIiilIIII1I1llilI11Ili",DELAY="IIlIiIliiiillIi1lilii1lill1I";
 static ClassLoader hierarchy;
 static String enabled(String c){return c.equals(T)?"i1iIi1lI1lii1i1lll1iil11":DELAY;}
 static String phase(String c){return c.equals(T)?"liliIl1li11l1IIilIlI1l1l":"lI1i1ll1iIIlll1IIiii";}
 static InsnList args(String c){InsnList x=new InsnList();x.add(new FieldInsnNode(GETSTATIC,c,enabled(c),"Z"));x.add(new InsnNode(c.equals(V)?ICONST_1:ICONST_0));return x;}
 static byte[] patch(byte[] b){
  ClassNode c=new ClassNode();new ClassReader(b).accept(c,ClassReader.SKIP_FRAMES);boolean v=c.name.equals(V);int updates=0,leads=0;
  for(MethodNode m:c.methods){
   if(c.name.equals(T)&&m.name.equals(DELAY)&&m.desc.equals("()J")){
    m.instructions.clear();m.tryCatchBlocks.clear();if(m.localVariables!=null)m.localVariables.clear();
    m.instructions.add(new FieldInsnNode(GETSTATIC,T,"llliilIillilIiiIi","I"));m.instructions.add(new MethodInsnNode(INVOKESTATIC,H,"delayMillis","(I)J",false));m.instructions.add(new InsnNode(LRETURN));
   }
   if(m.name.equals(UPDATE)&&m.desc.equals("()V")){
    updates++;
    // Entry hook owns revival while dead, before inventory/runtime recipe returns.
    InsnList pre=args(c.name);LabelNode alive=new LabelNode();pre.add(new MethodInsnNode(INVOKESTATIC,H,"revive","(ZZ)Z",false));pre.add(new JumpInsnNode(IFEQ,alive));
    pre.add(new InsnNode(ICONST_1));pre.add(new FieldInsnNode(PUTSTATIC,c.name,v?"II11lill1IiiIll11II1IIIiI":"l111IIiIl1illl1lllI","Z"));pre.add(new InsnNode(RETURN));pre.add(alive);m.instructions.insert(pre);
    AbstractInsnNode anchor=null;boolean sawLow=false;
    for(AbstractInsnNode n:m.instructions.toArray()){
     if(n instanceof MethodInsnNode){MethodInsnNode call=(MethodInsnNode)n;
      if(call.owner.equals(c.name)&&call.name.equals(v?"IIiillll1iI1I1il11lIli1ll":"i1l1llIIIl11llII1i")&&call.desc.equals("()V")){if(v){anchor=n;break;}sawLow=true;}
     }
     if(!v&&sawLow&&n instanceof FieldInsnNode&&n.getOpcode()==GETSTATIC&&((FieldInsnNode)n).owner.equals(P+"IIIiilililIilIli")&&((FieldInsnNode)n).name.equals("IIIiiiiliIl1Iiiii11")){anchor=n;break;}
    }
    if(anchor==null)throw new IllegalStateException("No lead hook "+c.name);
    InsnList lead=new InsnList();LabelNode check=new LabelNode(),normal=new LabelNode();
    lead.add(new FieldInsnNode(GETSTATIC,c.name,phase(c.name),"I"));lead.add(new InsnNode(ICONST_2));lead.add(new JumpInsnNode(IF_ICMPEQ,check));
    lead.add(new FieldInsnNode(GETSTATIC,c.name,phase(c.name),"I"));lead.add(new InsnNode(ICONST_3));lead.add(new JumpInsnNode(IF_ICMPNE,normal));lead.add(check);
    lead.add(new InsnNode(v?ICONST_1:ICONST_0));lead.add(new MethodInsnNode(INVOKESTATIC,H,"beforeLead","(Z)Z",false));lead.add(new JumpInsnNode(IFEQ,normal));lead.add(new InsnNode(RETURN));lead.add(normal);m.instructions.insertBefore(anchor,lead);leads++;
    for(AbstractInsnNode n:m.instructions.toArray())if(n.getOpcode()==RETURN){InsnList post=args(c.name);post.add(new FieldInsnNode(GETSTATIC,c.name,phase(c.name),"I"));post.add(new MethodInsnNode(INVOKESTATIC,H,"fence","(ZZI)V",false));m.instructions.insertBefore(n,post);}
   }
  }
  MethodNode stop=new MethodNode(ACC_PUBLIC|ACC_STATIC,"hsoLeashStop","()V",null,null);
  stop.instructions.add(new MethodInsnNode(INVOKESTATIC,c.name,v?"llIIilIiiiIl1lII11":"IIiillll1iI1I1il11lIli1ll","()V",false));
  if(v){stop.instructions.add(new MethodInsnNode(INVOKESTATIC,"java/lang/System","currentTimeMillis","()J",false));stop.instructions.add(new FieldInsnNode(PUTSTATIC,V,"Illllll1l1iII11llI1IIll111iI","J"));stop.instructions.add(new InsnNode(ICONST_0));stop.instructions.add(new FieldInsnNode(PUTSTATIC,V,"I1lIl1l11lilIll111I11IIiIi","I"));}
  else{stop.instructions.add(new InsnNode(ICONST_0));stop.instructions.add(new FieldInsnNode(PUTSTATIC,T,"II11lill1IiiIll11II1IIIiI","Z"));}
  stop.instructions.add(new InsnNode(RETURN));c.methods.add(stop);
  if(updates!=1||leads!=1)throw new IllegalStateException("Unexpected patch counts");
  ClassWriter w=new ClassWriter(ClassWriter.COMPUTE_FRAMES|ClassWriter.COMPUTE_MAXS){protected String getCommonSuperClass(String a,String b){try{Class<?> x=Class.forName(a.replace('/','.'),false,hierarchy),y=Class.forName(b.replace('/','.'),false,hierarchy);if(x.isAssignableFrom(y))return a;if(y.isAssignableFrom(x))return b;if(x.isInterface()||y.isInterface())return "java/lang/Object";do{x=x.getSuperclass();}while(!x.isAssignableFrom(y));return x.getName().replace('.','/');}catch(Exception ex){throw new IllegalStateException(a+" / "+b,ex);}}};c.accept(w);return w.toByteArray();
 }
 public static void main(String[] a)throws Exception{
  List<URL> urls=new ArrayList<URL>();urls.add(Paths.get(a[0]).toUri().toURL());urls.add(Paths.get(a[1]).toUri().toURL());try(DirectoryStream<Path> ds=Files.newDirectoryStream(Paths.get(a[2]),"*.jar")){for(Path p:ds)urls.add(p.toUri().toURL());}hierarchy=new URLClassLoader(urls.toArray(new URL[0]),PatchTradeV4.class.getClassLoader());
  try(JarFile z=new JarFile(a[0]);JarOutputStream out=new JarOutputStream(Files.newOutputStream(Paths.get(a[3])))){
   Enumeration<JarEntry> en=z.entries();while(en.hasMoreElements()){JarEntry e=en.nextElement();byte[] b;try(InputStream in=z.getInputStream(e)){ByteArrayOutputStream buf=new ByteArrayOutputStream();byte[] tmp=new byte[16384];int n;while((n=in.read(tmp))!=-1)buf.write(tmp,0,n);b=buf.toByteArray();}
    if(e.getName().equals(T+".class")||e.getName().equals(V+".class"))b=patch(b);
    JarEntry ne=new JarEntry(e.getName());ne.setTime(e.getTime());out.putNextEntry(ne);out.write(b);out.closeEntry();
   }
   if(!a[4].equals("-")){out.putNextEntry(new JarEntry(H+".class"));out.write(Files.readAllBytes(Paths.get(a[4])));out.closeEntry();}
  }
  System.out.println("V4: both actual trading updates patched for direct in-place revival, leash and stun wait; Farm unchanged.");
 }
}
