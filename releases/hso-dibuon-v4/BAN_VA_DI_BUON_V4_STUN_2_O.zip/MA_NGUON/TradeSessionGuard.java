package mod;

import IIlIiIliiiillIi1lilii1lill1I.i1liIIii1IlIl1illlIIilIl;
import IIlIiIliiiillIi1lilii1lill1I.i1i11I1iil1lIl;
import IIlIiIliiiillIi1lilii1lill1I.l1l11llilI1lllIi11;
import IIlIiIliiiillIi1lilii1lill1I.IIIIliIilIIili1I1l11;
import IIlIiIliiiillIi1lilii1lill1I.IIIiilililIilIli;
import java.io.FileWriter;

/** Trading only. Does not read or change the Farm revival mode. */
public final class TradeSessionGuard {
    private static Object deadCharacter, deadScene, followed;
    private static long deathAt, sentAt;
    private static boolean sent, waiting, wasStunned, deadV3;
    private static short[] approachPath;
    private static int approachX,approachY;
    private static int attempts;
    private static final int TILE=24, RADIUS=48, RESUME=24;
    private TradeSessionGuard() {}

    public static long delayMillis(int seconds) {
        return seconds<=1 ? 0L : Math.min(seconds,15)*1000L;
    }
    private static boolean valid(boolean enabled, boolean v3) {
        if(!enabled || (!v3 && ModAutoTradeV3.IIlIiIliiiillIi1lilii1lill1I)) return false;
        if(i1liIIii1IlIl1illlIIilIl.i1iiIi11IIilI1IiiIl11==null ||
            IIIiilililIilIli.IIIiiiiliIl1Iiiii11==null) return false;
        if(!mod.i1liIIii1IlIl1illlIIilIl.IIlIiIliiiillIi1lilii1lill1I("auto_dibuon")) return false;
        if(mod.IIIiilililIilIli.IliIl1i11Ilii1li1II1iIl("ModAutoDungeon")) return false;
        return !v3 || (!ModAutoKhuMuaBan.IIlIiIliiiillIi1lilii1lill1I() &&
            !mod.illIi1ilI1IIi1iii.IIlIiIliiiillIi1lilii1lill1I() &&
            !mod.liiI1lilIlilli11ii1Il.IIlIiIliiiillIi1lilii1lill1I());
    }
    private static boolean dead(l1l11llilI1lllIi11 p) {
        return p.IlIIl1I1IIIililIil1iiI==4 || p.ilIII1111l1i1liIil11<=0;
    }
    private static void stop(boolean v3) {
        if(v3) ModAutoTradeV3.hsoLeashStop(); else ModAutoTrade.hsoLeashStop();
        i1i11I1iil1lIl p=i1liIIii1IlIl1illlIIilIl.i1iiIi11IIilI1IiiIl11;
        if(p==null) return;
        p.li1i1ll1liIIlIlI1IlII=null;
        p.l1i1ili1Iill11Ii1iIII11liI1=0; p.iIIlI1lI1lIlI1il1liiiI1l=0;
        p.Ii1iliII1l1I1III1l=p.l1IilIi1ilil1lli1I1lii1Ill;
        p.iIlIi1iIi11IlI=p.l11iliIII1ii1lilI1IlIl;
        p.i1IiI111lIllI1lIIlI=0; p.iliI1liil1llii111Ililil=0;
        p.l1l1iIiIiIlIi1l11=0;
    }
    private static void resetDeath() {
        deadCharacter=null;deadScene=null;deathAt=0;sentAt=0;sent=false;attempts=0;
    }
    public static boolean revive(boolean enabled, boolean v3) {
        try {
            if(!valid(enabled,v3)) { if(deadCharacter!=null && deadV3==v3) resetDeath(); return false; }
            i1i11I1iil1lIl p=i1liIIii1IlIl1illlIIilIl.i1iiIi11IIilI1IiiIl11;
            if(!dead(p)) {
                if(deadCharacter==p && sent) log("alive after_ms="+((System.nanoTime()-deathAt)/1000000L)+" requests="+attempts);
                resetDeath();return false;
            }
            long now=System.nanoTime();
            Object scene=IIIiilililIilIli.IIIiiiiliIl1Iiiii11;
            if(deadCharacter!=p || deadScene!=scene) {
                resetDeath();deadCharacter=p;deadScene=scene;deathAt=now;deadV3=v3;
                log("death observed delay_setting="+ModAutoTrade.llliilIillilIiiIi+" mode="+(v3?"V3":"classic"));
            }
            waiting=false;followed=null;approachPath=null;stop(v3);
            long delay=delayMillis(ModAutoTrade.llliilIillilIiiIi)*1000000L;
            // No initial wait at setting 1. Bound retries to four per second.
            if((!sent && now-deathAt>=delay) || (sent && now-sentAt>=Math.max(delay,250000000L))) {
                // Existing in-place action used by BOTH the target and reference.
                // Resource consumption (revival item / gems) is decided by the game.
                IIIIliIilIIili1I1l11.l1lli1lIliIiiiIliIilII().l1lli1lIliIiiiIliIilII((short)-51,(byte)0,(byte)0);
                sentAt=now;sent=true;attempts++;
                if(attempts==1) log("in_place_request elapsed_ms="+((now-deathAt)/1000000L));
            }
            return true;
        } catch(Throwable failure) {
            // Keep ownership of a dead trading character; never fall through to
            // a competing revival mode or a flood of unthrottled old requests.
            if(deadCharacter!=null) {sent=true;sentAt=System.nanoTime();return true;}
            return false;
        }
    }
    public static boolean stunned(l1l11llilI1lllIi11 animal) {
        // Real movement-blocking flags, set/cleared by game effect handlers.
        return animal.iIIIli1Ilil1Ili11lli1 || animal.liiIIil1i1iIII1i ||
            animal.lIi1i1li1I1llii11Iii1i1ll || animal.Ilii1iIIIIlIil1ii ||
            animal.Il1IIii1lllIlIlIl1II1ii1iIl;
    }
    private static int distance(int x,int y,l1l11llilI1lllIi11 a) {
        return Math.abs(x-a.l1IilIi1ilil1lli1I1lii1Ill)+Math.abs(y-a.l11iliIII1ii1lilI1IlIl);
    }
    public static boolean beforeLead(boolean v3) {
        i1i11I1iil1lIl p=i1liIIii1IlIl1illlIIilIl.i1iiIi11IIilI1IiiIl11;
        l1l11llilI1lllIi11 a=ModAutoTrade.llIIilIiiiIl1lII11();
        if(p==null || a==null || dead(p) || a.ilIII1111l1i1liIil11<=0 || a.iIlii1I1Ili1iIIllIiI1IiIliI) {
            waiting=false;wasStunned=false;followed=null;return false;
        }
        if(followed!=a) {waiting=false;wasStunned=false;followed=a;}
        int d=distance(p.l1IilIi1ilil1lli1I1lii1Ill,p.l11iliIII1ii1lilI1IlIl,a);
        boolean stun=stunned(a);
        boolean recovering=waiting;
        if(stun || d>=RADIUS) waiting=true;
        if(waiting && !stun && d<=RESUME) waiting=false;
        if(!waiting) {
            if(recovering) stop(v3); // discard approach path, rebuild trade route
            wasStunned=false;approachPath=null;return false;
        }
        if(stun && !wasStunned) log("animal_stun wait_beside");
        wasStunned=stun;
        // Do not restart the same path every tick: that would repeatedly walk
        // back to its first node instead of reaching the animal.
        if(d>RESUME && approachPath!=null && p.li1i1ll1liIIlIlI1IlII==approachPath &&
            approachX==a.l1IilIi1ilil1lli1I1lii1Ill && approachY==a.l11iliIII1ii1lilI1IlIl) return true;
        stop(v3);
        approachPath=null;
        if(d>RESUME) {
            // Normal obstacle-aware walking, never a teleport/coordinate edit.
            short[] path=i1liIIii1IlIl1illlIIilIl.lIlIIIIIiiiiII1l1l1iII1l1().IIlIiIliiiillIi1lilii1lill1I(
                a.l1IilIi1ilil1lli1I1lii1Ill/TILE,a.l11iliIII1ii1lilI1IlIl/TILE,
                p.l1IilIi1ilil1lli1I1lii1Ill/TILE,p.l11iliIII1ii1lilI1IlIl/TILE,500);
            if(path!=null && path.length>0 && path.length<500) {
                p.li1i1ll1liIIlIlI1IlII=path;
                approachPath=path;approachX=a.l1IilIi1ilil1lli1I1lii1Ill;approachY=a.l11iliIII1ii1lilI1IlIl;
                p.i1IiI111lIllI1lIIlI=a.l1IilIi1ilil1lli1I1lii1Ill;
                p.iliI1liil1llii111Ililil=a.l11iliIII1ii1lilI1IlIl;
            }
        }
        return true;
    }
    public static void fence(boolean enabled,boolean v3,int phase) {
        try {
            if(!valid(enabled,v3)) return;
            if(phase!=2 && phase!=3) {waiting=false;followed=null;return;}
            i1i11I1iil1lIl p=i1liIIii1IlIl1illlIIilIl.i1iiIi11IIilI1IiiIl11;
            l1l11llilI1lllIi11 a=ModAutoTrade.llIIilIiiiIl1lII11();
            if(dead(p)||a==null||a.ilIII1111l1i1liIil11<=0||a.iIlii1I1Ili1iIIllIiI1IiIliI) return;
            int d=distance(p.l1IilIi1ilil1lli1I1lii1Ill,p.l11iliIII1ii1lilI1IlIl,a);
            if(stunned(a) && d<=RESUME) {stop(v3);return;}
            if(waiting) return; // approach path belongs to beforeLead
            short[] path=p.li1i1ll1liIIlIlI1IlII;
            if(path==null) return;
            if(p.l1l1iIiIiIlIi1l11>0 && distance(p.Ii1iliII1l1I1III1l,p.iIlIi1iIi11IlI,a)>RADIUS) {stop(v3);waiting=true;return;}
            int end=path.length;
            for(int k=Math.max(0,p.l1l1iIiIiIlIi1l11);k<path.length;k++) {
                int x=(byte)(path[k]>>8)*TILE+TILE/2,y=(byte)path[k]*TILE+TILE/2;
                if(k==path.length-1 && p.i1IiI111lIllI1lIIlI>0 && p.iliI1liil1llii111Ililil>0) {x=p.i1IiI111lIllI1lIIlI;y=p.iliI1liil1llii111Ililil;}
                if(distance(x,y,a)>RADIUS) {end=k;break;}
            }
            if(end<=p.l1l1iIiIiIlIi1l11) {stop(v3);waiting=true;return;}
            if(end<path.length) {
                short[] clipped=new short[end];System.arraycopy(path,0,clipped,0,end);
                p.li1i1ll1liIIlIlI1IlII=clipped;p.i1IiI111lIllI1lIIlI=0;p.iliI1liil1llii111Ililil=0;
            }
        } catch(Throwable failure) { stop(v3); }
    }
    private static void log(String event) {
        String line="[TRADE_V4] "+event;
        System.out.println(line);
        if("false".equals(System.getProperty("hso.trade.diagnostic"))) return;
        try {FileWriter out=new FileWriter("trade-v4-diagnostic.log",true);try {out.write(System.currentTimeMillis()+" "+line+"\n");}finally {out.close();}}catch(Exception ignored) {}
    }
}
