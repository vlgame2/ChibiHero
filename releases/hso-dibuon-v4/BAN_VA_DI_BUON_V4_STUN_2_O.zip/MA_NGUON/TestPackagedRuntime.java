import java.io.File;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.net.URL;
import java.net.URLClassLoader;

/** Open the exact repacked Runtime.dat with the unchanged production launcher. */
public final class TestPackagedRuntime {
 public static void main(String[] args)throws Exception {
  URLClassLoader launch=new URLClassLoader(new URL[]{new File(args[0]).toURI().toURL()},ClassLoader.getPlatformClassLoader());
  Class<?> factory=Class.forName("EncryptedRuntimeLoader",true,launch);
  Method open=factory.getDeclaredMethod("open",File.class);open.setAccessible(true);
  Object runtime=open.invoke(null,new File(args[1]));
  Method create=runtime.getClass().getDeclaredMethod("createClassLoader",ClassLoader.class);create.setAccessible(true);
  ClassLoader game=(ClassLoader)create.invoke(runtime,launch);
  for(String name:new String[]{"mod.TradeSessionGuard","mod.ModAutoTrade","mod.ModAutoTradeV3","mod.TradeFastBridge","mod.BachHoServerPolicy"}) {
   Class<?> c=Class.forName(name,false,game);c.getDeclaredMethods();
   if(c.getClassLoader()!=game)throw new AssertionError("Stale class loader: "+name);
   System.out.println("Packaged production memory loader PASS: "+name);
  }
  Class<?> trade=Class.forName("mod.ModAutoTrade",true,game);
  Field seconds=trade.getField("llliilIillilIiiIi");Method delay=trade.getMethod("IIlIiIliiiillIi1lilii1lill1I");
  for(int value:new int[]{1,2,15}) {seconds.setInt(null,value);long actual=((Long)delay.invoke(null)).longValue();if(actual!=(value==1?0L:value*1000L))throw new AssertionError("Instrumented delay getter: "+value);}
  System.out.println("Instrumented production loader delay settings 1/2/15 PASS.");
  Method close=runtime.getClass().getMethod("close");close.invoke(runtime);launch.close();
  System.out.println("PASS: original Launcher verified all 14 repacked bundles and resolved the five patch classes. No GUI, login or game-server calls.");
 }
}
