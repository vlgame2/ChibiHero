from pathlib import Path
import subprocess
R=Path('/workspace/tool-review');W=R/'trade-v4'
cp=':'.join(str(p) for p in (R/'tools').glob('asm*.jar'))
def run(*args):subprocess.run([str(v) for v in args],check=True,cwd=W)
run('java','-jar',R/'tools/ecj.jar','-source','8','-target','8','-encoding','UTF-8','-cp',cp,'-d',W/'classes',W/'src/PatchTradeV4.java')
args=['java','-cp',str(W/'classes')+':'+cp,'PatchTradeV4',R/'patched-resources/mod-auto-dibuon.jar',R/'server-fix/core-bachho8.jar',R/'target-resources',W/'mod-auto-dibuon.jar']
run(*args,'-')
gamecp=':'.join([str(W/'mod-auto-dibuon.jar'),str(R/'server-fix/core-bachho8.jar')]+[str(p) for p in (R/'target-resources').glob('*.jar')])
run('java','-jar',R/'tools/ecj.jar','-source','8','-target','8','-encoding','UTF-8','-cp',gamecp,'-d',W/'classes',W/'src/TradeSessionGuard.java')
run(*args,W/'classes/mod/TradeSessionGuard.class')
